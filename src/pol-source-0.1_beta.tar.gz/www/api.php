<?php
include('inc-functions.php');
@include('/home/teoriza/public_html/_blogs/conectar-mysql.php');
$link = conectar('com');
ob_start('ob_gzhandler');


//Funciones
function api_pass() { return substr(md5(mt_rand(1000000000,9999999999)), 0, 12); }


/*
api.php
?pass=48fdbfb12e5a
&a=transferir
*/

if (($_GET['a']) AND ($_GET['pass'])) {
	header('Content-Type: text/plain');
	$txt = 'pass error';
	//check PASS
	$result = mysql_query("SELECT ID, nick, pols FROM pol_users WHERE api_pass = '" . trim($_GET['pass']) . "' LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){
		$txt = 'ok';

		//acciones
		switch ($_GET['a']) {
			case 'debug': $txt = "debug: nick|user_ID|POLs\n" . $row['nick'] . "|" . $row['ID'] . "|" . $row['pols'] . "\n"; break;

			case 'transferencia': 
				$txt = 'error';

				if ((ctype_digit($_GET['pols'])) AND ($_GET['destino']) AND ($_GET['concepto'])) {
					$pols = $_GET['pols'];
					if ($_GET['destino']) { $origen = $_GET['destino']; } else { $origen = $row['ID']; }
					$destino = $_GET['destino'];
					$concepto = strip_tags(trim($_GET['concepto']));


					//pols_transferir($pols, $emisor_ID, $receptor_ID, $concepto);

				} else { $txt = 'error'; }


				break;
		} 



		//mysql_query("UPDATE pol_estudios_users SET cargo = '1' WHERE ID_estudio = '" . $cargo_ID . "' AND user_ID = '" . $user_ID . "' AND estado = 'ok' LIMIT 1", $link);
	}

	echo $txt;
	
} else {

	echo '<html>
<head>
<title>API POL 1.0</title>

<style type="text/css">
li em { color:green; font-size:18px; }
</style>

</head>
<body>

<h1>API POL &nbsp; 1.0</h1>

<p>La utilidad de esta API es facilitar a los no-humanos la ejecuci&oacute;n de acciones en POL. Esto permitir&aacute; crear aplicaciones externas que hagan automatismos o procesos en lote.</p>

<blockquote>

<h2>1. Nomenclatura:</h2>

<p>Las consultas a la API se hacen mediante par&aacute;metros en una URL, metodo GET (al menos de momento). Hay dos par&aacute;metros esenciales, par&aacute;metro "pass" (la clave personal API) y el parametro "a" (acci&oacute;n).</p>

<p>Ejemplo: <em>http://pol.teoriza.com/api.php?pass=55d4bf2edf8b&a=debug</em></p>

<h2>2. Clave API:</h2>

<p>La clave API es un c&oacute;digo de 12 caracteres alfanum&eacute;ricos. Por ejemplo: <em>55d4bf2edf8b</em>. Este c&oacute;digo debe mantenerse en secreto, ya que equivale a la contrase&ntilde;a. Esta clave permite el acceso restringido a la API, identificando a un Ciudadano. Por lo tanto una clave API efect&uacute;a acciones equivalentes a las de un Ciudadano normal.</p> 

<p>En caso de verse comprometida la clave o una simple sospecha de esto, se debe generar una nueva contrase&ntilde;a que anular&iacute;a la antigua. Este control est&aacute; en el perfil y puede hacerse tantas veces se quiera.</p>

<p>En caso de introducirse una clave incorrecta, devolver&aacute; siempre: "pass error".</p>

<h2>3. Acciones:</h2>

<p>La API permite DOS tipos de acciones: <b>ejecutar acciones</b> y <b>obtener informaci&oacute;n</b>.</p>

<p>Nota: los par&aacute;metros a continuaci&oacute;n deben ir precedidos de: <em>http://pol.teoriza.com/api.php?pass=CLAVE_API</em></p>

<blockquote>

<h3>3.1. Ejecutar acciones:</h3>
<ul>
<li><em>&a=<b>transferencia</b></em><br />
<em>&pols=POLS</em> &nbsp; (n�mero)<br />
<em>&origen=cuenta_ID</em> &nbsp; (opcional, solo necesario en caso de que el origen sea una cuenta bancaria)<br />
<em>&destino=NICK|cuenta_ID</em> &nbsp; (nick o ID en negativo de una cuenta en concreto, ejemplo: -1)<br />
<em>&concepto=TEXTO</em><br />
Transfiere una cantidad de POLs desde tu Ciudadano o una cuenta de tu propiedad, a otro Ciudadano o cuenta cual quiera. Verifica si los datos son correctos y si hay fondos suficientes. En caso de petici&oacute;n erronea no efectua ninguna acci&oacute;n.<br />EN CONSTRUCCION.<br />
</li>
</ul>

<h3>3.2. Obtener informaci&oacute;n:</h3>
<ul>
<li><em>a=<b>debug</b></em><br />
Permite hacer un test. Devuelve informaci&oacute;n sobre tu propio usuario.</li>
</ul>

</blockquote>

</blockquote>

<hr />

<p><a href="http://gonzo.teoriza.com/">GONZO</a> - 2008 - <a href="http://pol.teoriza.com/">http://pol.teoriza.com/</a></p>
</body></html>';

}



ob_end_flush();
if ($link) { mysql_close($link); }
?>