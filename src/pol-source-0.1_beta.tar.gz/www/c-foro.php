<?php 
include('inc-login.php');
/*
pol_foros			(`ID` `url` `title` `descripcion` `acceso` `time` `estado`)
pol_foros_hilos		(`ID` `sub_ID``url` `user_ID` `title` `time` `time_last` `text` `cargo` `num`)
pol_foros_msg		(`ID``hilo_ID` `user_ID` `time` `text` `cargo`)
*/

function foro_enviar($subforo, $hilo=null, $edit=null) {
	global $pol, $link, $return_url;

	if ($pol['estado'] == 'ciudadano') {


		if ($edit) { //editar

			$return_url = '/foro/';

			if ($hilo) { //msg
				$result = mysql_query("SELECT text, cargo FROM pol_foros_msg WHERE ID = '" . $hilo . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $edit_text = $row['text']; $edit_cargo = $row['cargo']; }
			} else { //hilo
				$result = mysql_query("SELECT sub_ID, text, cargo FROM pol_foros_hilos WHERE ID = '" . $subforo . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $edit_text = $row['text']; $edit_cargo = $row['cargo']; }
			}

			$edit_text = str_replace("<br /><br />", "", $edit_text);
			$edit_text = str_replace("&lt;", "&amp;lt;", $edit_text);
			$edit_text = str_replace("&gt;", "&amp;gt;", $edit_text);
		}



		if ($pol['nivel'] > 1) {
			$result = mysql_query("SELECT ID_estudio, 
(SELECT nombre FROM pol_estudios WHERE pol_estudios.ID = ID_estudio LIMIT 1) AS nombre,
(SELECT nivel FROM pol_estudios WHERE pol_estudios.ID = ID_estudio LIMIT 1) AS nivel
FROM pol_estudios_users  WHERE estado = 'ok' AND cargo = '1' AND user_ID = '" . $pol['user_ID'] . "'
ORDER BY nivel DESC", $link);
			while($row = mysql_fetch_array($result)){
				if ($edit_cargo == $row['ID_estudio']) { $selected = ' selected="selected"'; } else { $selected = ''; }
				$select_cargos .= '<option value="' . $row['ID_estudio'] . '"' . $selected . '>' . $row['nombre'] . '</option>' . "\n";
			}
		}

		if ((!$hilo) AND (!$edit)) { 
			$html .= '<div id="enviar">
<form action="/accion.php?a=foro&b=hilo" method="post">
<input type="hidden" name="subforo" value="' . $subforo . '"  />
<input type="hidden" name="return_url" value="' . $return_url . '"  />

<h2>Nuevo hilo</h2>

<p>T&iacute;tulo:<br />
<input name="title" size="60" maxlength="200" type="text"></p>

<p>Mensaje:<br />
<textarea name="text" style="color: green; font-weight: bold; width: 570px; height: 250px;">' . $edit_text . '</textarea></p>

<p><input value="Enviar" type="submit"> En calidad de: <select name="encalidad" style="color:green;font-weight:bold;font-size:17px;">' . $select_cargos . '<option value="0">Ciudadano</option>
</select></p>

</div>';
		} else {
			if ($edit) { $get = 'editar'; } else { $get = 'reply'; } 
			$html .= '<div id="enviar">
<form action="/accion.php?a=foro&b=' . $get . '" method="post">
<input type="hidden" name="subforo" value="' . $subforo . '"  />
<input type="hidden" name="hilo" value="' . $hilo . '"  />
<input type="hidden" name="return_url" value="' . $return_url . '"  />

<h2>Respuesta</h2>

<p>Mensaje:<br />
<textarea name="text" style="color: green; font-weight: bold; width: 570px; height: 250px;">' . $edit_text . '</textarea></p>

<p><input value="Enviar" type="submit"> En calidad de: <select name="encalidad" style="color:green;font-weight:bold;font-size:17px;">' . $select_cargos . '<option value="0">Ciudadano</option>
</select></p>

</form>
</div>';
		}
		return $html;
	} else { return '<p><b>Debes ser Ciudadano para participar, <a href="http://www.teoriza.com/registrar/">reg&iacute;strate aqu&iacute;!</a></b></p>'; }
}

function print_lateral($nick, $cargo, $time='') {
	if (!$cargo) { $cargo = 'Ciudadano'; } 
	$html .= '<b>' . crear_link($nick) . '<br />' . $cargo . '</b><br />' . duracion(time() - strtotime($time)) .  '<br /><br />';
	return $html;
}




/*
pol_foros			(`ID` `url` `title` `descripcion` `acceso` `time` `estado`)
pol_foros_hilos		(`ID` `sub_ID``url` `user_ID` `title` `time` `time_last` `text` `cargo` `num`)
pol_foros_msg		(`ID``hilo_ID` `user_ID` `time` `text` `cargo`)
*/
if ($_GET['a'] == 'editar') {
	$txt .= '<h1><a href="/foro/">Foro</a>: editar</h1>';

	$txt .= foro_enviar($_GET['b'], $_GET['c'], true);

} elseif ($_GET['b']) {			//foro/subforo/hilo-prueba/

	$result = mysql_query("SELECT ID, sub_ID, user_ID, url, title, time, time_last, text, cargo, num, 
(SELECT nick FROM pol_users WHERE ID = pol_foros_hilos.user_ID LIMIT 1) AS nick,
(SELECT nombre FROM pol_estudios WHERE ID = pol_foros_hilos.cargo LIMIT 1) AS encalidad
FROM pol_foros_hilos
WHERE url = '" . $_GET['b'] . "'
LIMIT 1", $link);
	while($row = mysql_fetch_array($result)) {
		$subforo = $_GET['a'];
		$return_url = '/foro/' . $subforo . '/' . $row['url'] . '/';
		paginacion('hilo', $return_url, $row['ID'], $_GET['c'], $row['num']);
		
		if ($_GET['c']) { $pag_title = ' - P&aacute;gina: ' . $_GET['c']; }
		$txt_title = $row['title'] . ' - Foro: ' . ucfirst($_GET['a']) . $pag_title;
		$txt .= '<h1><a href="/foro/">Foro</a>: <a href="/foro/' . $_GET['a'] . '/">' . ucfirst($_GET['a']) . '</a> &gt; <a href="' . $return_url . '">' . $row['title'] . '</a></h1>

<p style="margin-bottom:0;">' .  $p_paginas . ' &nbsp; ' . boton('Responder', '#enviar') . ' &nbsp; <b>' . $row['num'] . '</b> respuestas, desde <em>' . explodear(' ', $row['time'], 0) . '</em></p>



<table border="0" cellpadding="2" cellspacing="0" class="pol_table">';
		if (($pol['user_ID'] == $row['user_ID']) AND ($row['sub_ID'] != 5)) { $editar = '<span style="float:right;">' . boton('Editar', '/foro/editar/' . $row['ID'] . '/') . '</span>'; } else { $editar = ''; }
		$txt .= '<tr class="amarillo"><td align="right" valign="top">' . print_lateral($row['nick'], $row['encalidad'], $row['time']) . '</td><td valign="top" width="80%"><p style="text-align:justify;">' . $editar . $row['text'] . '</p></td></tr>';

		$result2 = mysql_query("SELECT ID, hilo_ID, user_ID, time, text, cargo,
(SELECT nick FROM pol_users WHERE ID = pol_foros_msg.user_ID LIMIT 1) AS nick,
(SELECT nombre FROM pol_estudios WHERE ID = pol_foros_msg.cargo LIMIT 1) AS encalidad
FROM pol_foros_msg
WHERE hilo_ID = '" . $row['ID'] . "'
ORDER BY time ASC
LIMIT " . $p_limit, $link);
		while($row2 = mysql_fetch_array($result2)) {
			if (($pol['user_ID'] == $row2['user_ID']) AND ($row['sub_ID'] != 5)) { $editar = '<span style="float:right;">' . boton('Editar', '/foro/editar/' . $row2['hilo_ID'] . '/' . $row2['ID'] . '/') . boton('X', '/accion.php?a=foro&b=eliminarreply&ID=' . $row2['ID'] . '&hilo_ID=' . $row2['hilo_ID'], '&iquest;Est&aacute;s seguro de querer ELIMINAR este MENSAJE?') . '</span>'; } else { $editar = ''; }
			$txt .= '<tr><td align="right" valign="top">' . print_lateral($row2['nick'], $row2['encalidad'], $row2['time']) . '</td><td valign="top"><p class="pforo">' . $editar . $row2['text'] . '</p></td></tr>';
		}
		$txt .= '</table>';
		$txt .= '<p>' . $p_paginas . '</p>';
		$txt .= foro_enviar($row['sub_ID'], $row['ID']);
		$txt_header .= '<style type="text/css">.pforo { text-align:justify; margin:2px; }</style>';
	}




} elseif ($_GET['a']) {	//foro/subforo/

	$result = mysql_query("SELECT ID, url, title, descripcion, acceso, time
FROM pol_foros
WHERE url = '" . $_GET['a'] . "' AND estado = 'ok'
LIMIT 1", $link);
	while($row = mysql_fetch_array($result)) {
		$return_url = '/foro/' . $_GET['a'] . '/';
		
		$txt_title = 'Foro: ' . ucfirst($_GET['a']) . ' - ' . $row['descripcion'];
		$txt .= '<h1><a href="/foro/">Foro</a>: <a href="/foro/' . $_GET['a'] . '/">' . ucfirst($_GET['a']) . '</a></h1>

<p style="margin-bottom:0;">' . boton('Crear Hilo', '#enviar') . ' (' . $row['descripcion'] . ')</p>

<table border="0" cellpadding="1" cellspacing="0" class="pol_table">
<tr>
<th>Autor</th>
<th></th>
<th>Hilo</th>
<th>Creado</th>
<th></th>
</tr>';
		$result2 = mysql_query("SELECT ID, url, user_ID, title, time, time_last, cargo, num, sub_ID,
(SELECT nick FROM pol_users WHERE ID = pol_foros_hilos.user_ID LIMIT 1) AS nick
FROM pol_foros_hilos
WHERE sub_ID = '" . $row['ID'] . "'
ORDER BY time_last DESC
LIMIT 50", $link);
		while($row2 = mysql_fetch_array($result2)) {
			if ($pol['user_ID'] == $row2['user_ID']) { $editar = ' ' . boton('X', '/accion.php?a=foro&b=eliminarhilo&ID=' . $row2['ID'], '&iquest;Est&aacute;s seguro de querer ELIMINAR este HILO?'); } else { $editar = ''; }
			$txt .= '<tr><td align="right">' . crear_link($row2['nick']) . '</td><td align="right"><b>' . $row2['num'] . '</b></td><td><a href="/foro/' . $row['url'] . '/' . $row2['url'] . '/"><b>' . $row2['title'] . '</b></a></td><td align="right">' . duracion(time() - strtotime($row2['time'])) . '</td><td>' . $editar . '</td></tr>';
		}
		$txt .= '</table><br />';
		$txt .= foro_enviar($row['ID']);
	}





} else {						//foro/
	$txt_title = 'Foro';
	$txt .= '<h1><a href="/foro/">Foro</a>:</h1>
<br />
<table border="0" cellpadding="1" cellspacing="0" class="pol_table">';

	$result = mysql_query("SELECT ID, url, title, descripcion,
(SELECT COUNT(*) FROM pol_foros_hilos WHERE sub_ID = pol_foros.ID LIMIT 1) AS num
FROM pol_foros
WHERE estado = 'ok'
ORDER BY time ASC", $link);
	while($row = mysql_fetch_array($result)) {
		$txt .= '<tr class="amarillo"><td width="120"><h2><a href="/foro/' . $row['url'] . '/" style="font-size:19px;margin-left:8px;"><b>' . $row['title'] . '</b></a></h2></td><td align="right"><b style="font-size:19px;">' . $row['num'] . '</b></td><td style="color:green;">' . $row['descripcion'] . '</td><td align="right" width="10%">' . boton('Crear Hilo', '/foro/' . $row['url'] . '/#enviar') . '</td></tr>';

		$result2 = mysql_query("SELECT ID, url, user_ID, title, time, time_last, cargo, num,
(SELECT nick FROM pol_users WHERE ID = pol_foros_hilos.user_ID LIMIT 1) AS nick
FROM pol_foros_hilos
WHERE sub_ID = '" . $row['ID'] . "'
ORDER BY time_last DESC
LIMIT 5", $link);
		while($row2 = mysql_fetch_array($result2)) {
			$hilo_url[$row2['ID']] = '<a href="/foro/' . $row['url'] . '/' . $row2['url'] . '/">' . $row2['title'] . '</a>';
			$txt .= '<tr><td align="right" valign="top">' . crear_link($row2['nick']) . '</td><td valign="top" align="right"><b>' . $row2['num'] . '</b></td><td><b>' . $hilo_url[$row2['ID']] . '</b></td><td align="right" valign="top">' . duracion(time() - strtotime($row2['time'])) . '</td></tr>';

		}
		$txt .= '<tr><td colspan="4">&nbsp;</td></tr>';
	}

	$txt .= '<tr><td colspan="4">&nbsp;</td></tr>';
	$txt .= '<tr class="amarillo"><td colspan="4"><h2 style="font-size:18px;padding:8px;">Ultimas 6 respuestas:</h2></tr>';

	$result = mysql_query("SELECT ID, hilo_ID, user_ID, time, text,
(SELECT nick FROM pol_users WHERE ID = pol_foros_msg.user_ID LIMIT 1) AS nick,
(SELECT nombre FROM pol_estudios WHERE ID = pol_foros_msg.cargo LIMIT 1) AS encalidad
FROM pol_foros_msg
ORDER BY time DESC
LIMIT 6", $link);
	while($row = mysql_fetch_array($result)) {
		$txt .= '<tr><td align="right" valign="top" colspan="2">' . print_lateral($row['nick'], $row['encalidad'], $row['time']) . '</td><td valign="top" colspan="2"><p style="text-align:justify;margin:1px;">' . $hilo_url[$row['hilo_ID']] . '<br />' . $row['text'] . '</p></td></tr>';
	}


	$txt .= '</table>';
}

$txt_header .= '<style type="text/css">
h1 a { color:#4BB000; }
#enviar {
background:#FFFFB7;
padding:20px 0 20px 50px;
}
</style>';


//THEME
include('theme.php');
?>