<?php

if ($pol['estado'] == 'ciudadano') { 
	$rsegundos = '5';
	$time_pre = date('Y-m-d H:i:00', time() - 18000); //5h 
} else {
	$rsegundos = '15';
	$time_pre = date('Y-m-d H:i:00', time() - 900); //15min 
}



$result = mysql_unbuffered_query("SELECT 
ID_msg, msg, user, time, type, user_ID
FROM pol_chat_" . $pol['chat_sql'] . " 
WHERE time > '" . $time_pre . "'
ORDER BY time DESC 
LIMIT 20", $link);
while($row = mysql_fetch_array($result)){

	if (($row['user_ID'] == 0) OR ($row['user_ID'] == $pol['user_ID'])) {
		$li_msg++;
		$time = explode(" ", $row['time']);
		$time = explode(":", $time[1]);
		$time = $time[0] . ':' . $time[1];
		if ($pol['estado'] == 'ciudadano') { $li_color_gris = ' class="oldc"'; }


		if ($row['type'] == '#') {
			$li = '<li id="' . $row['ID_msg'] . '"' . $li_color_gris . '>' . $time . ' <span class="chat_accion">' . $row['msg'] . '</span></li>' . "\n" . $li;
		} else {

			if ($row['type'] == '@') { 
				$es_algo = '<img src="/img/policia-mini.gif" alt="Policia" border="0" /> ';
			} elseif ($row['type'] == '+') {
				$es_algo = '<img src="/img/gobierno-mini.gif" alt="Gobierno" border="0" /> ';
			} else { $es_algo = ''; }

			$li = '<li id="' . $row['ID_msg'] . '"' . $li_color_gris . '>' . $time . ' ' . $es_algo . '<b>' . $row['user'] . '</b>: ' . $row['msg'] . '</li>' . "\n" . $li;
		}
	}

	if (!$lastid) { $lastid = $row['ID_msg']; }
}
if (!$lastid) { 
	$result = mysql_unbuffered_query("SELECT ID_msg FROM pol_chat_" . $pol['chat_sql'] . " ORDER BY ID_msg DESC LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){ $lastid = $row['ID_msg']; }
}

//rellena chat vacio
if ($li_msg < 22) {
	$li_msg = 22 - $li_msg;
	for ($i=0;$i<$li_msg;$i++) { $li = '<li>&nbsp;</li>' . "\n" . $li; }
}


$txt .= '<p class="chat_title">' . $pol['chat_nombre'] .'</p>';





//user es policia | 12 Policia, 18 Secreta, 13 Comisario
$result = mysql_unbuffered_query("SELECT ID FROM pol_estudios_users WHERE user_ID = '" . $pol['user_ID'] . "' AND cargo = '1'  AND (ID_estudio = '12' OR ID_estudio = '18' OR ID_estudio = '13') LIMIT 1", $link);
while($row = mysql_fetch_array($result)){
	$js_kick = '<a href=\"/form/expulsar/" + lowernick  + "/\" target=\"_blank\"><img src=\"/img/expulsar.gif\" alt=\"Expulsar\" border=\"0\" /></a> ';
}



$time_margen = date('Y-m-d H:i:00', time() - 900); //15 min
$result = mysql_unbuffered_query("SELECT DISTINCT user
FROM pol_chat_" . $pol['chat_sql'] . "
WHERE time > '" . $time_margen . "'
ORDER BY user DESC 
LIMIT 100", $link);
while($row = mysql_fetch_array($result)){
	if ($array_listd) { $array_listd .= ', '; } $array_listd .= '"' . $row['user'] . '" : "' . time() . '"';
}

if ($array_listd) { $array_list = 'array_list = {' . $array_listd . '};'; }

$txt .= '<div id="chat_users">
<ul id="chat_list">
</ul>
</div>';



$txt .= '<div id="chatmsg">
<ul id="chatmsgul">
' . $li . '
</ul>
</div>';



if ($pol['estado'] == 'ciudadano') {
	$txt .= '
<div id="chatform">
<form action="" method="POST" onSubmit="return enviarmsg();">
<input type="submit" value="Enviar" id="botonenviar" style="float:right;width:190px;" />
<input type="text" name="msg" value="" id="mensaje" autocomplete="off" size="65" maxlength="255" style="float:left;width:74%;" onkeydown="catchTAB(event,this);" />
</form>
</div>';
} else {
$txt .= '<p><b>Para escribir en el chat debes ser Ciudadano de POL, <a href="http://www.teoriza.com/registrar/">reg&iacute;strate aqu&iacute;!</a></b></p>';
}


if ($pol['nick'] == 'GONZOdfgdfg') {
	$txt .= '
<div id="chatstatus">
<input id="chat_status" type="text" value="Conectando..." size="50" readonly="readonly" />
</div>';
	$print_status = '	$("#chat_status").attr("value", "id:" + idmsg + " - delay:" + chat_delay + " - " +  txt);';
}


$txt_header .= '
<style type="text/css">
#chatmsg { height:350px; overflow:auto; background:white; }
#chatmsg ul { padding:0; margin:0; position:static; }
#chatmsg ul li { padding:0; margin:0; color:#666666; background:none; font-size:15px; list-style:none;}
#chatmsg .oldc { color:#A3A3A3; }
#chatmsg ul li:before { content:\'\'; }
#chat_users { float:right; width:170px; height:350px; overflow:auto; margin-left:20px; background:white; }
#chat_users ul { padding:0; margin:0; position:static; }
#chat_users ul li { padding:0; margin:0; color:#666666; background:none; font-size:18px; font-weight:bold; list-style:none;}
#chat_users ul li:before { content:\'\'; }
#chat_users li { font-weight:bold; text-size:18px; }
#chat_users a { color:grey; text-decoration:none; }
#chat_users a:hover { text-decoration:underline; }
.chat_title { font-weight:bold; font-size:20px; color:green; margin:0; padding:0; }
.chat_accion { color:green; font-size:16px; }
</style>


<script type="text/javascript" src="http://pol.teoriza.com/img/jquery.js"></script>
<script type="text/javascript">

// INICIO
idmsg = parseInt("' . $lastid . '");
elnick = "' . $pol['nick'] . '";
ajax_refresh = true;
chat_delay = ' . $rsegundos . '000;
chat_delay1 = "";
chat_delay2 = "";
chat_delay3 = setTimeout("change_delay(10000)", 60000);
chat_delay4 = setTimeout("change_delay(15000)", 120000);
chat_delay5 = setTimeout("change_delay(60000)", 300000);


array_list = new Array();
' . $array_list . '

window.onload = function(){
	document.getElementById("chatmsg").scrollTop = 100000;
	$("#mensaje").focus();
	refresh = setTimeout(chat_query_ajax, chat_delay);
	check_list();
}


// FUNCIONES

var obj;
function catchTAB(evt,elem) {
	obj = elem;
	var keyCode;
	if ("which" in evt) { keyCode=evt.which; }
	else if ("keyCode" in evt) { keyCode=evt.keyCode; } 
	else if ("keyCode" in window.event) { keyCode=window.event.keyCode; } 
	else if ("which" in window.event) { keyCode=evt.which; }

	if (keyCode == 9) {
		var elmsg = $("#mensaje").attr("value").toLowerCase();
		var elmsg_len = elmsg.length;
		for (elnick in array_list) {
			var elmnick = elnick.toLowerCase();
			if (elmsg == elmnick.substr(0,elmsg_len)) { obj.value = elnick + " "; }
		}
		setTimeout("obj.focus()",1);
	}
}




function chat_query_ajax() {
	print_status("Refresh...");
	ajax_refresh = false;
	clearTimeout(refresh);
	$.get("http://pol.teoriza.com/ajax.php?id=' . $pol['chat_sql'] . '&n=" + idmsg,
	function(data){
		ajax_refresh = true;
		if (data) {
			print_msg(data);
			print_status("Refresh ok");
		}
		refresh = setTimeout(chat_query_ajax, chat_delay);
		print_status("...");
	}
	);
	if (ajax_refresh == true) { check_list(); }
}

function print_msg(data) {
	if (ajax_refresh) {
		var arraydata = data.split("\n");
		var msg_num = arraydata.length - 1;
		var list = "";
		for (i=0;i<msg_num;i++) {
			var mline = arraydata[i].split(" ");

			if (mline[0] == "#") {
				var txt = ""; var ml = mline.length; for (var e=4; e<ml; e++) { txt += mline[e] + " "; }

				list += "<li id=\"" + mline[1] + "\">" + mline[2] + " <span class=\"chat_accion\">" + txt + "</span></li>\n";
			} else if (mline[0] == "_") {
			} else { 
				var txt = ""; var ml = mline.length; for (var e=4; e<ml; e++) { txt += mline[e] + " "; }

				var poli = "";
				switch (mline[0]) {
					case "@": poli = "<img src=\"/img/policia-mini.gif\" alt=\"Policia\" border=\"0\" /> "; break;
					case "+": poli = "<img src=\"/img/gobierno-mini.gif\" alt=\"Gobierno\" border=\"0\" /> "; break;
				}


				list += "<li id=\"" + mline[1] + "\">" + mline[2] + " " + poli + "<b>" + mline[3] + "</b>: " + txt + "</li>\n";
				check_list(mline[3], mline[0]);
			}
		}
		$("#chatmsgul").append(list);
		idmsg = parseInt(idmsg) + parseInt(msg_num);
		print_delay();
	}
}

function check_list(nick, type) {
	var unix_timestamp = parseInt(new Date().getTime().toString().substring(0, 10));
	if (nick) { array_list[nick] = unix_timestamp; }
	var list = "";
	for (elnick in array_list) {
		if (array_list[elnick] < parseInt(unix_timestamp - 900)) { //900 15min
			array_list[elnick] = null;
		} else {
			if (array_list[elnick]) {
				var lowernick = elnick.toLowerCase();
				list += "<li>' . $js_kick . '<a href=\"/perfil/" + lowernick  + "/\">" + elnick + "</a></li>\n";
			}
		}
	}
	$("#chat_list").html(list);
}

function print_delay() {
	$("#mensaje").focus();
	$("#chatmsg #" + idmsg).hide();
	setTimeout(function(){
		$("#chatmsg #" + idmsg).fadeIn("slow"); 
		document.getElementById("chatmsg").scrollTop = 100000;
	}, 200);
}

function enviarmsg() {
	var elmsg = $("#mensaje").attr("value");
	if (elmsg) {
		ajax_refresh = false;
		clearTimeout(refresh); 
		$("#botonenviar").attr("disabled","disabled");
		$("#mensaje").attr("value","");
		$.post("http://pol.teoriza.com/ajax.php?a=enviar&id=' . $pol['chat_sql'] . '&n=" + idmsg, { uid: "' . $pol['user_ID'] . '", nick: "' . $pol['nick'] . '", msg: elmsg }, 
		function(data){ 
			ajax_refresh = true;
			if (data) {
				print_msg(data);
				chat_delay = 3000;
				print_status("MSG ENVIADO...");
			}
			refresh = setTimeout(chat_query_ajax, chat_delay);

			setTimeout(function(){ $("#botonenviar").removeAttr("disabled"); }, 1500);
			clearTimeout(chat_delay1); chat_delay1 = setTimeout("change_delay(4000)", 10000);
			clearTimeout(chat_delay2); chat_delay2 = setTimeout("change_delay(6000)", 20000);
			clearTimeout(chat_delay3); chat_delay3 = setTimeout("change_delay(10000)", 60000);
			clearTimeout(chat_delay4); chat_delay4 = setTimeout("change_delay(15000)", 120000);
			clearTimeout(chat_delay5); chat_delay5 = setTimeout("change_delay(60000)", 300000);
		} );
	}
	return false;
}

function change_delay(delay) {
	chat_delay = delay; 
	print_status("time...");
}

function print_status(txt) {
' . $print_status . '
}

</script>';

?>