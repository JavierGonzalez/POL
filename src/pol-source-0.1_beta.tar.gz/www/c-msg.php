<?php 
include('inc-login.php');

if ($pol['estado'] == 'ciudadano') {

if ($_GET['a']) {

	if ($_GET['a'] != 'enviar') { $pre_nick = strtolower($_GET['a']); }

	$result = mysql_query("SELECT ID, nombre, num_cargo
FROM pol_estudios
WHERE asigna != '-1'
ORDER BY nivel DESC", $link);
	while($row = mysql_fetch_array($result)){
		$select_todoscargos .= '<option value="' . $row['ID'] . '">(' . $row['num_cargo'] . ') ' . $row['nombre'] . '</option>';
	}

	//tus cargos
	$result = mysql_query("SELECT ID_estudio, 
(SELECT nombre FROM pol_estudios WHERE pol_estudios.ID = ID_estudio LIMIT 1) AS nombre
FROM pol_estudios_users 
WHERE estado = 'ok' 
AND cargo = '1'
AND user_ID = '" . $pol['user_ID'] . "'
ORDER BY nombre ASC", $link);
	while($row = mysql_fetch_array($result)){
		$select_cargos .= '<option value="' . $row['ID_estudio'] . '">' . $row['nombre'] . '</option>';
	}


	$txt_header .= '
<script type="text/javascript" src="http://pol.teoriza.com/img/jquery.js"></script>
<script type="text/javascript">

window.onload = function(){
	$("#ciudadano").focus();
}

function click_cuenta() {
$("#ciudadano").attr("value","");
$("#radio_ciudadano").removeAttr("checked");
$("#radio_cuenta").attr("checked","checked");
}

function click_ciudadano() {
$("#radio_cuenta").removeAttr("checked");
$("#radio_ciudadano").attr("checked","checked");
}

</script>';

	$txt .= '<h1><img src="/img/email.gif" alt="Msg" /> Enviar mensaje</h1>

<form action="/accion.php?a=enviar-mensaje" method="post">

<p>Para:<table border="0">
<tr onclick="click_ciudadano();">
<td><input id="radio_ciudadano" type="radio" name="para" value="ciudadano" checked="checked" />Ciudadano:</td>
<td> <input id="ciudadano" tabindex="1" type="text" name="nick" value="' . $pre_nick . '" style="font-size:17px;" /></td>
</tr>
<tr onclick="click_cuenta();">
<td><input id="radio_cuenta" type="radio" name="para" value="cargo" />Cargo:</td>
<td><select name="cargo_ID" style="color:green;font-weight:bold;font-size:17px;">' . $select_todoscargos . '</select> (env&iacute;o m&uacute;ltiple, cuidado)</td>
</tr>
</table>
</p>

<p>Mensaje:<br />
<textarea tabindex="2" name="text" style="color:green;font-weight:bold;width:550px;height:200px;"></textarea></p>

<p><input type="checkbox" name="urgente" value="1" /> Env&iacute;o certificado urgente. (el receptor recibir&aacute; un email, solo urgencias)</p>


<p><input type="submit" value="Enviar" /> En calidad de: <select name="calidad" style="color:green;font-weight:bold;font-size:17px;"><option value="0">Ciudadano</option>' . $select_cargos . '</select> &nbsp; <a href="/msg/"><b>Ver mensajes</b></a></form></p>';



} else {
	$txt .= '<h1><img src="/img/email.gif" alt="Msg" /> Tus mensajes privados</h1>';
	$txt .= '<p>' . boton('Enviar mensaje', '/msg/enviar/') . '</p>';

$txt .= '<table border="0" cellspacing="0" cellpadding="0" width="100%" class="pol_table" id="msg_table">
<tr>
<th></th>
<th>De</th>
<th width="100%">Mensaje</th>
<th></th>
</tr>';

	$result = mysql_query("SELECT 
ID, envia_ID, recibe_ID, time, text, leido, 
(SELECT nick FROM pol_users WHERE pol_users.ID = envia_ID LIMIT 1) AS nick_envia,
(SELECT nombre FROM pol_estudios WHERE pol_estudios.ID = cargo LIMIT 1) AS cargo
FROM pol_mensajes
WHERE recibe_ID = '" . $pol['user_ID'] . "'
ORDER BY time DESC
LIMIT 50", $link);
	while($row = mysql_fetch_array($result)){
		if ($row['leido'] == 0) {
			$boton = '<input type="checkbox" name="option2" onClick="window.location.href=\'/accion.php?a=mensaje-leido&ID=' . $row['ID'] . '\';"  checked />';
			$fondo = ' style="background:#FFFFCC;"';
			
		} else {
			$boton = '<input type="checkbox" name="option2" />';
			$fondo = '';
		}

		$minitable = '
<table border="0" cellspacing="0" cellpadding="0" style="margin:0;padding:0;">
<tr>
<td>' . boton('Responder', '/msg/' . strtolower($row['nick_envia']) . '/') . '</td>
<td>' . boton('X', '/accion.php?a=borrar-mensaje&ID=' . $row['ID'], '&iquest;Seguro que deseas ELIMINAR este mensaje?') . '</td>
</tr>
<tr>
<td colspan="2">' . $row['time'] . '</td>
</tr>
</table>';

		if (!$row['cargo']) { $row['cargo'] = 'Ciudadano'; }
		$txt .= '<tr' . $fondo . '><td valign="top">' . $boton . '</td><td valign="top"><b>' . crear_link($row['nick_envia']) . '</b><br /><b>' . str_replace(' ', '&nbsp;', $row['cargo']) . '</b></td><td valign="top">' . $row['text'] . '<hr /></td><td valign="top">' . $minitable . '</td></tr>' . "\n";
	}

	if (!$boton) { $txt .= '<tr><td colspan="5"><b>No tienes ning&uacute;n mensaje.</b></td></tr>'; }

	$txt .= '</table>';
	
	$txt .= '<p>' . boton('Enviar mensaje', '/msg/enviar/') . '</p>';

}

}

//THEME
include('theme.php');
?>