<?php 
if ($link) { mysql_close($link); }
if (!$txt) {  
	header('HTTP/1.1 301 Moved Permanently');
	header('Location: http://pol.teoriza.com/');
	exit;
}
if (!$txt_description) { $txt_description = $txt_title . ' | POL'; }
if ($txt_title) { $txt_title .= ' _ POL'; } else { $txt_title = 'POL _ El Pueblo Virtual'; }


ob_start('ob_gzhandler');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title><?=$txt_title?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link href="http://pol.teoriza.com/img/style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" />
<meta name="language" content="es_ES" />
<meta name="description" content="<?=$txt_description?>" />

<?=$txt_header?>

</head>

<body class="fullwidth">
<div id="container">
<div id="header">
<div id="header-in">

<?php
$nick_lower = strtolower($pol['nick']);

if ($pol['estado'] == 'ciudadano') { // ciudadano

if ($pol['msg'] > 0) { $num_msg = '<b style="font-size:18px;">' . $pol['msg'] . '</b>'; } else { $num_msg = $pol['msg']; }
if ($pol['config']['elecciones_estado'] == 'normal') {  
	$elecciones_quedan = duracion(strtotime($pol['config']['elecciones_inicio']) - time());
	$elecciones = ' <a href="/info/elecciones-generales/">Elecciones en <b style="font-size:18px;">' . $elecciones_quedan . '</b></a> |'; 
} elseif ($pol['config']['elecciones_estado'] == 'elecciones') {  
	$elecciones_quedan = duracion((strtotime($pol['config']['elecciones_inicio']) + $pol['config']['elecciones_duracion']) - time());
	$elecciones = ' <a href="/info/elecciones-generales/"><b>Elecciones en curso</b>, queda <b style="font-size:18px;">' .  $elecciones_quedan . '</b></a> |'; 
}
$txt_perfil = '<a href="/perfil/' . $nick_lower . '/">' . $pol['nick'] . ' <img src="/img/perfil.gif" alt="Perfil" border="0" /></a> | <a href="/pols/"><b>' . pols($pol['pols']) . '</b> POLs</a> | <a href="/msg/" title="Mensajes">(' . $num_msg . ') <img src="/img/email.gif" alt="Mensajes" border="0" style="margin-bottom:-5px;" /></a> |' . $elecciones . ' <a href="/accion.php?a=logout">Salir</a>';

} elseif ($pol['estado'] == 'turista') { //turista ciudadanizando...
$txt_perfil = $pol['nick'] . ' (<span class="infog">Turista, ' . $pol['tiempo_ciudadanizacion'] . '</span>) | <a href="/perfil/' . $nick_lower . '/"><img src="/img/perfil.gif" alt="Perfil" border="0" /> Perfil</a> | <a href="/accion.php?a=logout">Salir</a>';

} elseif ($pol['nick']) {  //login ok, sin identificar
$txt_perfil = $pol['nick'] . ' (<span class="infog">Turista</span>) <a href="/form/solicitar-ciudadania/"><b>Solicitar ciudadan&iacute;a</b></a> | <a href="/accion.php?a=logout">Salir</a>';

} else { //sin identificar, sin login
$txt_perfil = '
<script type="text/javascript">
function vlgn (objeto) { if ((objeto.value == "Usuario") || (objeto.value == "123")) { objeto.value = ""; } }
</script>

<span style="float:right;">
<form action="http://www.teoriza.com/registrar/login.php?a=login" method="post">
<input name="url" value="' . base64_encode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) . '" type="hidden">
<input name="user" value="Usuario" size="6" maxlength="20" onfocus="vlgn(this)" type="text">
<input name="pass" value="123" size="6" maxlength="20" onfocus="vlgn(this)" type="password">
<input type="submit" value="Entrar" /></form>
</span>
	
<span>(<span class="infog">Sin registrar</span>) <a href="http://www.teoriza.com/registrar/"><b>Reg&iacute;strate!</b></a> | <a href="/recuperar-login/"><acronym title="Recuperar contrase&ntilde;a">?</acronym></a> &nbsp;</span>';

}
?>
<p><span style="float:right;"><?=$txt_perfil?></span><span id="homelogo"><a href="/" style="color:grey;" title="Home"><b>POL</b> | El Pueblo Virtual</a></span></p>


</div>
</div>
<div id="content-wrap" class="clear lcol">
<div class="column">
<div class="column-in">

<?php if (!$pol['nick']) { echo '<a href="/doc/que-es-pol-introduccion/" style="text-decoration:none;">&iquest;Qu&eacute; es POL?</a><br />'; } ?>
<p>Chats:<br />
<a href="/chat/plaza/"><b>Plaza</b></a><?php menu_in('/chat/plaza/'); ?><br />
<a href="/chat/parlamento/">Parlamento</a><?php menu_in('/chat/parlamento/'); ?><br />
<a href="/chat/comisaria/">Comisar&iacute;a</a><?php menu_in('/chat/comisaria/'); ?><br />
<a href="/chat/tribunales/">Tribunales</a><?php menu_in('/chat/tribunales/'); ?><br />
</p>

<p>Info:<br />
<a href="/doc/boletin-oficial-de-pol-bop/">BOP</a><?php menu_in('/doc/boletin-oficial-de-pol-bop/'); ?><br />
<a href="/foro/"><b>Foro</b></a><?php menu_in('/foro/'); ?><br />
<a href="/info/censo/">Censo</a><span class="md">(<?php echo $pol['config']['info_censo'] . ')</span>'; menu_in('/info/censo/'); ?><br />
<a href="/cargos/">Cargos</a><?php menu_in('/cargos/'); ?><br />
<a href="/partidos/">Partidos</a><span class="md">(<?php echo $pol['config']['info_partidos'] . ')</span>'; menu_in('/partidos/'); ?><br />
<a href="/referendum/">Consultas</a><span class="md">(<?php echo $pol['config']['info_consultas'] . ')</span>'; menu_in('/referendum/'); ?><br />
<a href="/doc/">Documentos</a><span class="md">(<?php echo $pol['config']['info_documentos'] . ')</span>'; menu_in('/doc/'); ?><br />
<?php
if ($pol['config']['elecciones_estado'] == 'elecciones') {
	echo '<a href="/info/elecciones-generales/"><b>Elecciones</b></a>'; menu_in('/info/elecciones-generales/');
} else {
	echo '<a href="/info/elecciones-generales/">Elecciones</a>'; menu_in('/info/elecciones-generales/');
}
?><br />
<a href="/empresas/">Empresas</a><?php menu_in('/empresas/'); ?><br />
<a href="/info/estadisticas/">Estad&iacute;sticas</a><?php menu_in('/info/estadisticas/'); ?><br />
<a href="/log-eventos/">Log Eventos</a><?php menu_in('/log-eventos/'); ?><br />
</p>

<?php if ($pol['estado'] == 'ciudadano') { ?>


<form name="acciones">
<select style="margin-left:-10px;" name="acc" onchange="window.location=(document.forms.acciones.acc[document.forms.acciones.acc.selectedIndex].value);">

<option selected="selected" value="#" style="font-weight:bold;">&darr; Acciones</option>

<optgroup label="Ciudadano">
<option value="/perfil/<?=$nick_lower?>/">Tu Perfil</option>
<option value="/msg/enviar/">Enviar mensaje</option>
<option value="/pols/">Transferir POLs</option>
<option value="/estudios/">Estudiar</option>
<option value="/form/afiliarse/">Afiliarse</option>
<option value="/form/crear-documento/">Crear documento</option>
</optgroup>

</select>
</form>


<?php } ?>

</div>
</div>
<div class="content">
<div class="content-in">

<?=$txt?>

</div>
</div>
</div>
<div class="clear"></div>
<div id="footer">
<div id="footer-in">

<?php 
$mtime = explode(' ', microtime()); 
$tiempofinal = $mtime[1] + $mtime[0]; 
$tiempototal = number_format($tiempofinal - $tiempoinicial, 3); 
?>



<div>
<span style="float:right;"><a href="http://www.teoriza.com/">Blogs Teoriza</a> | <?=$tiempototal?>s</span>
<b>POL</b> 3.0 <span style="font-size:12px;">(<a href="/doc/desarrollo-de-pol-30/">BETA</a>)</span>

<span class="amarillo" id="pols_frase"><b><?=$pol['config']['pols_frase']?></b> &nbsp; <a href="/mercado/frase/" style="color:grey;">Subasta</a>
<?php if ($pol['config']['pols_fraseedit'] == $pol['user_ID']) { echo ' <a href="/mercado/frase/editar/" style="color:grey;">Editar</a>'; } ?></span>
</div>


</div>
</div>
</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-59186-46");
pageTracker._trackPageview();
</script>

</body>
</html>
<?php ob_end_flush(); ?>