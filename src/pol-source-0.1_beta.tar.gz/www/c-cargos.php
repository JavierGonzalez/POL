<?php 
include('inc-login.php');

if ($_GET['a']) { //Editar Cargo:

	$result = mysql_query("SELECT ID, nombre, tiempo, nivel, num_cargo, salario
FROM pol_estudios
WHERE ID = '" . $_GET['a'] . "'
AND num_cargo != '0'
AND nivel <= '" . $pol['nivel'] . "'
LIMIT 1", $link);
	while($row = mysql_fetch_array($result)) {
		$txt .= '<h1><img src="/img/doc-edit.gif" alt="Editar" /> ' . $row['nombre'] . ' (Editar Cargo)</h1>';

		$txt .= '<ul>
<form action="/accion.php?a=cargo&b=edit&ID=' . $row['ID'] . '" method="post">
<li><input style="text-align:right;" type="text" name="plazas" size="5" maxlength="6" value="' . $row['num_cargo'] . '" /> plazas</li>
<li><input style="text-align:right;" type="text" name="tiempo" size="5" maxlength="10" value="' . $row['tiempo'] . '" /> segundos de estudio (' . duracion($row['tiempo']) . ')</li>
<li><input style="text-align:right;" type="text" name="salario" size="5" maxlength="10" value="' . $row['salario'] . '" /> POLs por dia trabajado (Salario actual: ' . $row['salario'] . ')<br />
<input type="submit" value="Guardar" /><br /></form><br /></li>';

		$result2 = mysql_query("SELECT user_ID, 
(SELECT nick FROM pol_users WHERE ID = pol_estudios_users.user_ID LIMIT 1) AS nick
FROM pol_estudios_users 
WHERE estado = 'ok' 
AND ID_estudio = '" . $row['ID'] . "'
AND cargo = '0'
AND user_ID != '" . $pol['user_ID'] . "'
ORDER BY nick ASC", $link);
		while($row2 = mysql_fetch_array($result2)){
			$ciudadanos .= '<option value="' . $row2['user_ID'] . '">' . $row2['nick'] . '</option>';
		}

		$txt .= '<li><form action="/accion.php?a=cargo&b=add&ID=' . $row['ID'] . '" method="post"><select name="user_ID">' . $ciudadanos . '</select> <input type="submit" value="Asignar este Cargo" /></form><br /></li></ul>';


		$a = 0;
		$result2 = mysql_query("SELECT user_ID, 
(SELECT nick FROM pol_users WHERE ID = pol_estudios_users.user_ID LIMIT 1) AS nick
FROM pol_estudios_users 
WHERE estado = 'ok'
AND ID_estudio = '" . $row['ID'] . "'
AND cargo = '1'
ORDER BY nick ASC", $link);
		while($row2 = mysql_fetch_array($result2)){
			$a++;
			$activos .= '<li><form action="/accion.php?a=cargo&b=del&ID=' . $row['ID'] . '" method="post"><input type="hidden" name="user_ID" value="' . $row2['user_ID'] . '"  /><input style="height:26px;" type="submit" value="X" /> <b>' . crear_link($row2['nick']) . '</b></form></li>';
		}

		$txt .= '<p><b style="color:green;">Activos: ' . $a . '</b></p><ol>' . $activos . '</ol><p><a href="/cargos/"><b>Ver Cargos</b></a></p>';
	}

} else {

	$txt .= '<h1>Cargos</h1>

<table border="0" cellspacing="3" cellpadding="0" class="pol_table">
<tr>
<th>Nivel&darr;</th>
<th width="200">Cargo</th>
<th><acronym title="Salario diario">Salario</acronym></th>
<th><acronym title="Plazas/(Cargos Ejercidos)">Plazas</acronym></th>
<th>Ciudadanos</th>
<th colspan="2">Asigna</th>

</tr>';

	$cargos = cargos();

	$result = mysql_query("SELECT 
ID, nombre, nivel, num_cargo, asigna, salario
FROM pol_estudios 
WHERE asigna != '-1'
ORDER BY nivel DESC", $link);
	while($row = mysql_fetch_array($result)){

		if (
		($pol['nivel'] > 100) OR
		(($row['asigna'] != 0) AND ($cargos[$row['asigna']]))
		) { 
			$p_edit = '<form><input style="margin-bottom:-16px;" type="button" value="Editar" onClick="window.location.href=\'/cargos/' . $row['ID'] . '/\';"></form>';
		} else { $p_edit = ''; }

		$c_nicks = '';
		$num = 0;
		$result2 = mysql_query("SELECT user_ID,
(SELECT nick FROM pol_users WHERE ID = pol_estudios_users.user_ID LIMIT 1) AS nick
FROM pol_estudios_users 
WHERE estado = 'ok'
AND cargo = '1'
AND ID_estudio = '" . $row['ID'] . "'
ORDER BY nick ASC
LIMIT " . $row['num_cargo'], $link);
		while($row2 = mysql_fetch_array($result2)){
			$num++;
			if ($c_nicks) { $c_nicks .= ', '; } 
			$c_nicks .= crear_link($row2['nick']);
		}


		switch ($row['asigna']) {
			case 0: $asignado_por = '<acronym title="Elecciones Generales">Elecciones</acronym>'; break;
			case 7: $asignado_por = 'Presidente'; break;
			case 13: $asignado_por = '<acronym title="Comisario de Polic&iacute;a">Comisario</acronym>'; break;
		}



		$txt .= '<tr><td align="right" valign="top"><b>' . $row['nivel'] . '</b></td><td valign="top"><b>' . $row['nombre'] . '</b></td><td align="right" valign="top">' . pols($row['salario']) . '</td><td align="right" valign="top"><b>' . $row['num_cargo'] . '</b>(' . $num . ')</td><td valign="top"><b>' . $c_nicks . '</b></td><td valign="top">' . $asignado_por . '</td><td valign="top">' . $p_edit . '</td></tr>';
	}
	$txt .= '</table>';

	$txt .= '<p>' . boton('Estudiar', '/estudios/') . ' &nbsp; <a href="/info/elecciones-generales/"><b>Ver Gobierno</b></a></p>';
}


//THEME
$txt_title = 'Cargos';
include('theme.php');
?>