<?php 
include('inc-login.php');


if  ($pol['estado'] == 'ciudadanoSSS')  { //ciudadanos

} else { //turistas

	$time_pre = date('Y-m-d H:i:00', time() - 900); //15m 
	$result = mysql_query("SELECT nick 
FROM pol_users 
WHERE fecha_last > '" . $time_pre . "'
ORDER BY fecha_last DESC", $link);
	while($row = mysql_fetch_array($result)){ $li_online_num++; if ($li_online) { $li_online .= ', '; } $li_online .= crear_link($row['nick']); }

	$result = mysql_query("SELECT siglas FROM pol_partidos 
ORDER BY fecha_creacion ASC", $link);
	while($row = mysql_fetch_array($result)){ $li_partidos_num++; if ($li_partidos) { $li_partidos .= ', '; } $li_partidos .= crear_link($row['siglas'], 'partido'); }

	if ($pol['config']['elecciones_estado'] == 'normal') {  
		$li_elecciones_num = 'en ' . duracion(strtotime($pol['config']['elecciones_inicio']) - time());
		$li_elecciones = '<a href="http://pol.teoriza.com/info/elecciones-generales/">Escrutinio, esca&ntilde;os y nuevo Gobierno</a>';
	} elseif ($pol['config']['elecciones_estado'] == 'elecciones') {  

		$fecha_24_antes = date('Y-m-d H:i:00', strtotime($pol['config']['elecciones_inicio']) - $pol['config']['elecciones_antiguedad']);
		$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_users WHERE estado = 'ciudadano' AND fecha_registro < '" . $fecha_24_antes . "'", $link);
		while($row = mysql_fetch_array($result)) { $num_votantes = $row['num']; }
		$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_elecciones", $link);
		while($row = mysql_fetch_array($result)) { $num_votos = $row['num']; }

		$elecciones_quedan = duracion((strtotime($pol['config']['elecciones_inicio']) + $pol['config']['elecciones_duracion']) - time());
		$li_elecciones_num = 'En curso';
		$li_elecciones = '<a href="http://pol.teoriza.com/info/elecciones-generales/">Participaci&oacute;n ' . round(($num_votos * 100) / $num_votantes) . '%, queda ' .  $elecciones_quedan . '</a>';
	}

	$txt .= '<h1>Bienvenido a POL</h1>
<br />
<table border="0"><tr><td width="60%" valign="top">

<h2>&iquest;Qu&eacute; es POL?</h2>
<p style="text-align:justify;">POL es un Pueblo Virtual. Puede ser comprendido como un <b>simulador pol&iacute;tico</b>, un <b>experimento sociol&oacute;gico</b>, una <b>red social</b> de Internet o bien como un simple <b>juego</b>.</p>

<p style="text-align:justify;">Nuestro Gobierno Democr&aacute;tico se compone de un Presidente, Diputados, Jueces, Polic&iacute;as, Leyes, Juicios, Periodistas, Abogados, etc... sin la existencia de usuarios privilegiados (god).</p>

<p style="text-align:justify;">En POL todos los ciudadanos est&aacute;n en absoluta igualdad, con las mismas oportunidades para el liderazgo o el fracaso en la b&uacute;squeda del Poder.</p>

<h2>C&oacute;mo ser Ciudadano</h2>
<ol>
<li><a href="http://www.teoriza.com/registrar/"><b>Reg&iacute;stra tu usuario de Teoriza</b></a>.</li>
<li>Valida el email.</li>
<li>Entra aqu&iacute; de nuevo, podr&aacute;s <a href="http://pol.teoriza.com/form/solicitar-ciudadania/"><b>solicitar la ciudadania!</b></a>.</li>
</ol>

</td><td valign="top">
	
<h2>Informaci&oacute;n Global</h2>
<ul id="info">
<li>Ciudadanos online: <b>' . $li_online_num . '<br />' . $li_online . '</b></li>
<li>Partidos Pol&iacute;ticos: <b>' . $li_partidos_num . '<br />' . $li_partidos . '</b></li>
<li>Elecciones Generales: <b>' . $li_elecciones_num . '<br />' . $li_elecciones . '</b></li>
</ul>


</td></tr></table>';

	$txt_header .= '<style type="text/css">#info li { margin-top:10px; } </style>';

}





//THEME
$txt_title = '';
include('theme.php');
?>