<?php 
if (!$link) {
	@include('inc-functions.php');
	@include('/home/teoriza/public_html/_blogs/conectar-mysql.php');
	$date = date('Y-m-d H:i:s');
	$link = conectar('com');
}

$margen_24h = date('Y-m-d H:i:s', time() - 86400); //24h
$margen_2dias = date('Y-m-d H:i:s', time() - 172800); //2dias
$margen_15dias = date('Y-m-d H:i:s', time() - 1296000); //15dias
$margen_30dias = date('Y-m-d H:i:s', time() - 2592000); //30dias


// SALARIOS
$result = mysql_query("SELECT user_ID,
(SELECT salario FROM pol_estudios WHERE  ID = pol_estudios_users.ID_estudio AND asigna != '-1' LIMIT 1) AS salario
FROM pol_estudios_users
WHERE cargo = '1' AND estado = 'ok'
ORDER BY user_ID ASC", $link);
while($row = mysql_fetch_array($result)){ if ($salarios[$row['user_ID']] < $row['salario']) { $salarios[$row['user_ID']] = $row['salario']; } }

foreach($salarios as $user_ID => $salario) {
	$result = mysql_query("SELECT ID
FROM pol_users
WHERE ID = '" . $user_ID . "' AND estado = 'ciudadano' AND fecha_last > '" . $margen_24h . "' 
LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){
		$txt .= $user_ID. ' - ' . $salario . "<br />\n";
		$gasto_total = $gasto_total + $salario;
		mysql_query("UPDATE pol_users SET pols = pols + " . $salario . " WHERE ID = '" . $user_ID . "' LIMIT 1", $link);
		mysql_query("INSERT INTO pol_transacciones (pols, emisor_ID, receptor_ID, concepto, time) VALUES ('" . $salario . "', '-1', '" . $user_ID . "', 'Sueldo', '" . $date . "')", $link);
	}

}
if ($gasto_total > 0) {
	mysql_query("UPDATE pol_cuentas SET pols = pols - " . $gasto_total . " WHERE ID = '1' LIMIT 1", $link);
}
enviar_email(null, "[POL] CRON 24h - Sueldos ejecutados", "Sueldos<br /><br />" . $txt, "gonzomail@gmail.com");
evento_chat('<b>[POLs] Sueldos efectuados.</b> Gasto total: <em>' . $gasto_total. ' POLs</em>');


// SUBASTA
$result = mysql_query("SELECT pols, user_ID,
(SELECT nick FROM pol_users WHERE ID = pol_pujas.user_ID LIMIT 1) AS nick,
(SELECT pols FROM pol_users WHERE ID = pol_pujas.user_ID LIMIT 1) AS nick_pols
FROM pol_pujas 
WHERE mercado_ID = '1' 
ORDER BY pols DESC LIMIT 1", $link);
while($row = mysql_fetch_array($result)){
	$puja_maxima = $row['pols'];
	if ($row['nick_pols'] >= $row['pols']) {
		pols_transferir($row['pols'], $row['user_ID'], '-1', 'Subasta de la frase publicitaria');
		mysql_query("UPDATE pol_config SET valor = '" . $row['user_ID'] . "' WHERE dato = 'pols_fraseedit' LIMIT 1", $link);
		evento_chat('<b>[POLs] Subasta finalizada.</b> Ganador ' . crear_link($row['nick']) . ' por <em>' . $row['pols'] . ' POLs</em>');
	} else {
		mysql_query("UPDATE pol_config SET valor = '' WHERE dato = 'pols_frase' LIMIT 1", $link); //resetea frase
	}
}
mysql_query("DELETE FROM pol_pujas WHERE mercado_ID = '1'", $link); //resetea pujas


//elimina mensajes privados de mas de 30 dias
mysql_query("DELETE FROM pol_mensajes WHERE time < '" . $margen_30dias . "'", $link); 


//ELIMINA CIUDADANOS INACTIVOS
$result = mysql_query("SELECT ID, nick FROM pol_users WHERE fecha_last < '" . $margen_15dias . "'", $link);
while($row = mysql_fetch_array($result)) { eliminar_ciudadano($row['ID']); }

//resetea referencias antiguas
mysql_query("DELETE FROM pol_referencias WHERE time < '" . $margen_15dias . "'", $link); 




// S T A T S

/*
pol_stats (ID, time, ciudadanos, nuevos, pols, pols_cuentas, transacciones, hilos_msg, pol_gobierno)
*/

// ciudadanos
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_users WHERE fecha_last > '" . $margen_15dias . "'", $link);
while($row = mysql_fetch_array($result)) { $st['ciudadanos'] = $row['num']; }

// nuevos
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_users WHERE fecha_registro > '" . $margen_24h . "'", $link);
while($row = mysql_fetch_array($result)) { $st['nuevos'] = $row['num']; }

// pols
$result = mysql_query("SELECT SUM(pols) AS num FROM pol_users WHERE fecha_last > '" . $margen_15dias . "'", $link);
while($row = mysql_fetch_array($result)) { $st['pols'] = $row['num']; }

// pols_cuentas
$result = mysql_query("SELECT SUM(pols) AS num FROM pol_cuentas", $link);
while($row = mysql_fetch_array($result)) { $st['pols_cuentas'] = $row['num']; }

// transacciones
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_transacciones WHERE time > '" . $margen_24h . "'", $link);
while($row = mysql_fetch_array($result)) { $st['transacciones'] = $row['num']; }

// hilos+msg
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_foros_hilos WHERE time > '" . $margen_24h . "'", $link);
while($row = mysql_fetch_array($result)) { $st['hilos_msg'] = $row['num']; }
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_foros_msg WHERE time > '" . $margen_24h . "'", $link);
while($row = mysql_fetch_array($result)) { $st['hilos_msg'] = $st['hilos_msg'] + $row['num']; }

// pols_gobierno
$result = mysql_query("SELECT pols AS num FROM pol_cuentas WHERE ID = '1'", $link);
while($row = mysql_fetch_array($result)) { $st['pol_gobierno'] = $row['num']; }

// partidos
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_partidos WHERE estado = 'ok'", $link);
while($row = mysql_fetch_array($result)) { $st['partidos'] = $row['num']; }

// empresas
$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_empresas", $link);
while($row = mysql_fetch_array($result)) { $st['empresas'] = $row['num']; }

// INSERT
mysql_query("INSERT INTO pol_stats 
(time, ciudadanos, nuevos, pols, pols_cuentas, transacciones, hilos_msg, pol_gobierno, partidos, frase, empresas) 
VALUES ('" . date('Y-m-d 20:00:00') . "', '" . $st['ciudadanos'] . "', '" . $st['nuevos'] . "', '" . $st['pols'] . "', '" . $st['pols_cuentas'] . "', '" . $st['transacciones'] . "', '" . $st['hilos_msg'] . "', '" . $st['pol_gobierno'] . "', '" . $st['partidos'] . "', '" . $puja_maxima . "', '" . $st['empresas'] . "')", $link);


mysql_close($link);
?>