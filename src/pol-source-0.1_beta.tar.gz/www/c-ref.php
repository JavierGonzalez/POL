<?php 
include('inc-login.php');

/*
pol_referencias (ID, user_ID, IP, time, referer)
*/

if (($_GET['a']) AND (!$pol['pols'])) {

	$result = mysql_query("SELECT ID FROM pol_users WHERE nick = '" . trim($_GET['a']) . "' LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){ 
		$IP = ip2long(isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
		mysql_query("INSERT INTO pol_referencias 
(user_ID, IP, time, referer) 
VALUES ('" . $row['ID'] . "', '" . $IP . "', '" . $date . "', '" . $_SERVER['HTTP_REFERER'] . "')", $link);
	}

	mysql_close($link);
	header('HTTP/1.1 301 Moved Permanently');
	header('Location: http://pol.teoriza.com/');
	exit;

} elseif ($_GET['a']) {
	$txt .= 'nick...';
}



//THEME
$txt_title = 'Ciudadano ' . $nick . ', perfil de usuario';
include('theme.php');
?>