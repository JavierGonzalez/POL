-- phpMyAdmin SQL Dump
-- version 2.11.9.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 15-10-2008 a las 15:12:13
-- Versión del servidor: 4.1.22
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `teoriza_gonzo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_ban`
--

CREATE TABLE IF NOT EXISTS `pol_ban` (
  `ID` smallint(5) NOT NULL auto_increment,
  `user_ID` mediumint(8) NOT NULL default '0',
  `autor` mediumint(8) NOT NULL default '0',
  `expire` datetime NOT NULL default '0000-00-00 00:00:00',
  `razon` text NOT NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `user_ID` (`user_ID`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_cat`
--

CREATE TABLE IF NOT EXISTS `pol_cat` (
  `ID` tinyint(3) NOT NULL auto_increment,
  `url` varchar(80) NOT NULL default '',
  `nombre` varchar(80) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `num` smallint(5) NOT NULL default '0',
  `nivel` tinyint(3) NOT NULL default '0',
  `tipo` enum('empresas','docs','cargos') NOT NULL default 'empresas',
  PRIMARY KEY  (`ID`),
  KEY `url` (`url`,`tipo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_chat_arts`
--

CREATE TABLE IF NOT EXISTS `pol_chat_arts` (
  `ID_msg` smallint(5) NOT NULL auto_increment,
  `user` varchar(14) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg` text NOT NULL,
  `type` enum('m','@','+','#') NOT NULL default 'm',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID_msg`),
  KEY `user` (`user`),
  KEY `time` (`time`),
  KEY `type` (`type`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=675 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_chat_comisaria`
--

CREATE TABLE IF NOT EXISTS `pol_chat_comisaria` (
  `ID_msg` smallint(5) NOT NULL auto_increment,
  `user` varchar(20) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg` text NOT NULL,
  `type` enum('m','@','+','#') NOT NULL default 'm',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID_msg`),
  KEY `user` (`user`),
  KEY `time` (`time`),
  KEY `type` (`type`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=435 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_chat_congreso`
--

CREATE TABLE IF NOT EXISTS `pol_chat_congreso` (
  `ID_msg` smallint(5) NOT NULL auto_increment,
  `user` varchar(20) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg` text NOT NULL,
  `type` enum('m','@','+','#') NOT NULL default 'm',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID_msg`),
  KEY `user` (`user`),
  KEY `time` (`time`),
  KEY `type` (`type`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1001 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_chat_gobierno`
--

CREATE TABLE IF NOT EXISTS `pol_chat_gobierno` (
  `ID_msg` smallint(5) NOT NULL auto_increment,
  `user` varchar(14) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg` text NOT NULL,
  `type` enum('m','@','+','#') NOT NULL default 'm',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID_msg`),
  KEY `user` (`user`),
  KEY `time` (`time`),
  KEY `type` (`type`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=314 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_chat_plaza`
--

CREATE TABLE IF NOT EXISTS `pol_chat_plaza` (
  `ID_msg` smallint(5) NOT NULL auto_increment,
  `user` varchar(14) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg` text NOT NULL,
  `type` enum('m','@','+','#') NOT NULL default 'm',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID_msg`),
  KEY `user` (`user`),
  KEY `time` (`time`),
  KEY `type` (`type`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3142 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_chat_tribunales`
--

CREATE TABLE IF NOT EXISTS `pol_chat_tribunales` (
  `ID_msg` smallint(5) NOT NULL auto_increment,
  `user` varchar(20) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg` text NOT NULL,
  `type` enum('m','@','+','#') NOT NULL default 'm',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID_msg`),
  KEY `user` (`user`),
  KEY `time` (`time`),
  KEY `type` (`type`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=706 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_config`
--

CREATE TABLE IF NOT EXISTS `pol_config` (
  `ID` smallint(5) NOT NULL auto_increment,
  `dato` varchar(30) NOT NULL default '',
  `valor` varchar(255) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `autoload` enum('si','no') NOT NULL default 'no',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `dato` (`dato`),
  KEY `autoload` (`autoload`),
  KEY `valor` (`valor`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_cuentas`
--

CREATE TABLE IF NOT EXISTS `pol_cuentas` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `nombre` varchar(20) NOT NULL default '',
  `user_ID` mediumint(8) NOT NULL default '0',
  `pols` int(10) NOT NULL default '0',
  `nivel` tinyint(3) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_diputados`
--

CREATE TABLE IF NOT EXISTS `pol_diputados` (
  `ID` smallint(5) NOT NULL auto_increment,
  `ID_partido` smallint(5) NOT NULL default '0',
  `user_ID` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_docs`
--

CREATE TABLE IF NOT EXISTS `pol_docs` (
  `ID` smallint(5) NOT NULL auto_increment,
  `user_ID` mediumint(8) NOT NULL default '0',
  `url` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `text` longtext NOT NULL,
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `time_last` datetime NOT NULL default '0000-00-00 00:00:00',
  `nivel` tinyint(3) NOT NULL default '0',
  `estado` enum('ok','del','borrador') NOT NULL default 'ok',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `url` (`url`),
  KEY `estado` (`estado`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_elecciones`
--

CREATE TABLE IF NOT EXISTS `pol_elecciones` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `ID_partido` smallint(5) NOT NULL default '0',
  `user_ID` mediumint(8) NOT NULL default '0',
  `nav` varchar(255) NOT NULL default '',
  `IP` varchar(30) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=146 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_empresas`
--

CREATE TABLE IF NOT EXISTS `pol_empresas` (
  `ID` smallint(5) NOT NULL auto_increment,
  `url` varchar(40) NOT NULL default '',
  `nombre` varchar(40) NOT NULL default '',
  `user_ID` mediumint(8) NOT NULL default '0',
  `descripcion` text NOT NULL,
  `web` varchar(200) NOT NULL default '',
  `cat_ID` tinyint(3) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `url` (`url`,`cat_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_estudios`
--

CREATE TABLE IF NOT EXISTS `pol_estudios` (
  `ID` smallint(5) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL default '',
  `tiempo` mediumint(9) NOT NULL default '86400',
  `nivel` tinyint(3) NOT NULL default '1',
  `num_cargo` smallint(5) NOT NULL default '1',
  `asigna` smallint(5) NOT NULL default '7',
  `salario` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `nivel` (`nivel`),
  KEY `nombre` (`nombre`),
  KEY `asigna` (`asigna`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_estudios_users`
--

CREATE TABLE IF NOT EXISTS `pol_estudios_users` (
  `ID` bigint(20) NOT NULL auto_increment,
  `ID_estudio` smallint(5) NOT NULL default '0',
  `user_ID` mediumint(8) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `estado` enum('ok','estudiando') NOT NULL default 'ok',
  `cargo` enum('0','1') NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `cargo` (`cargo`),
  KEY `estado` (`estado`),
  KEY `ID_estudio` (`ID_estudio`),
  KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1044 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_foros`
--

CREATE TABLE IF NOT EXISTS `pol_foros` (
  `ID` smallint(5) NOT NULL auto_increment,
  `url` varchar(50) NOT NULL default '',
  `title` varchar(50) NOT NULL default '',
  `descripcion` varchar(255) NOT NULL default '',
  `acceso` tinyint(3) NOT NULL default '1',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `estado` enum('ok') NOT NULL default 'ok',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `url` (`url`),
  KEY `estado` (`estado`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_foros_hilos`
--

CREATE TABLE IF NOT EXISTS `pol_foros_hilos` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `sub_ID` smallint(5) NOT NULL default '0',
  `url` varchar(80) NOT NULL default '',
  `user_ID` mediumint(8) NOT NULL default '0',
  `title` varchar(80) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `time_last` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `cargo` tinyint(3) NOT NULL default '0',
  `num` smallint(5) NOT NULL default '1',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `url` (`url`),
  KEY `sub_ID` (`sub_ID`),
  KEY `time_last` (`time_last`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_foros_msg`
--

CREATE TABLE IF NOT EXISTS `pol_foros_msg` (
  `ID` int(10) NOT NULL auto_increment,
  `hilo_ID` mediumint(8) NOT NULL default '0',
  `user_ID` mediumint(8) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `cargo` tinyint(3) NOT NULL default '1',
  PRIMARY KEY  (`ID`),
  KEY `foro_ID` (`hilo_ID`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=257 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_log`
--

CREATE TABLE IF NOT EXISTS `pol_log` (
  `ID` bigint(12) NOT NULL auto_increment,
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_ID` mediumint(8) NOT NULL default '0',
  `user_ID2` mediumint(8) NOT NULL default '0',
  `accion` tinyint(3) NOT NULL default '0',
  `dato` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2030 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_mensajes`
--

CREATE TABLE IF NOT EXISTS `pol_mensajes` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `envia_ID` mediumint(8) NOT NULL default '0',
  `recibe_ID` mediumint(8) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `leido` enum('0','1') NOT NULL default '0',
  `cargo` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `recibe_ID` (`recibe_ID`,`leido`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1171 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_mercado`
--

CREATE TABLE IF NOT EXISTS `pol_mercado` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `user_ID` mediumint(8) NOT NULL default '0',
  `title` varchar(90) NOT NULL default '',
  `descripcion` text NOT NULL,
  `pols` mediumint(8) NOT NULL default '0',
  `tipo` enum('subasta','venta','compra') NOT NULL default 'subasta',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `estado` enum('ok','old') NOT NULL default 'ok',
  PRIMARY KEY  (`ID`),
  KEY `tipo` (`tipo`,`estado`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_partidos`
--

CREATE TABLE IF NOT EXISTS `pol_partidos` (
  `ID` smallint(5) NOT NULL auto_increment,
  `ID_presidente` mediumint(7) NOT NULL default '0',
  `fecha_creacion` datetime NOT NULL default '0000-00-00 00:00:00',
  `siglas` varchar(6) NOT NULL default '',
  `nombre` varchar(40) NOT NULL default '',
  `descripcion` text NOT NULL,
  `estado` enum('ok') NOT NULL default 'ok',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `siglas` (`siglas`),
  UNIQUE KEY `ID_presidente` (`ID_presidente`),
  KEY `estado` (`estado`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_partidos_listas`
--

CREATE TABLE IF NOT EXISTS `pol_partidos_listas` (
  `ID` smallint(5) NOT NULL auto_increment,
  `ID_partido` smallint(5) NOT NULL default '0',
  `user_ID` mediumint(8) NOT NULL default '0',
  `orden` tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `user_ID` (`user_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_pujas`
--

CREATE TABLE IF NOT EXISTS `pol_pujas` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `mercado_ID` mediumint(8) NOT NULL default '0',
  `user_ID` mediumint(8) NOT NULL default '0',
  `pols` int(10) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`),
  KEY `mercado_ID` (`mercado_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=123 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_ref`
--

CREATE TABLE IF NOT EXISTS `pol_ref` (
  `ID` smallint(5) NOT NULL auto_increment,
  `pregunta` varchar(255) NOT NULL default '',
  `descripcion` text NOT NULL,
  `respuestas` text NOT NULL,
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `time_expire` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_ID` mediumint(8) NOT NULL default '0',
  `estado` enum('ok','end') NOT NULL default 'ok',
  `num` smallint(5) NOT NULL default '0',
  `tipo` enum('sondeo','referendum','parlamento') NOT NULL default 'sondeo',
  PRIMARY KEY  (`ID`),
  KEY `tipo` (`tipo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_referencias`
--

CREATE TABLE IF NOT EXISTS `pol_referencias` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `user_ID` mediumint(8) NOT NULL default '0',
  `IP` varchar(10) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `referer` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `IP` (`IP`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=139 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_ref_votos`
--

CREATE TABLE IF NOT EXISTS `pol_ref_votos` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `user_ID` mediumint(8) NOT NULL default '0',
  `ref_ID` smallint(5) NOT NULL default '0',
  `voto` tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ref_ID` (`ref_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=188 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_stats`
--

CREATE TABLE IF NOT EXISTS `pol_stats` (
  `ID` smallint(5) NOT NULL auto_increment,
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ciudadanos` smallint(5) NOT NULL default '0',
  `nuevos` smallint(5) NOT NULL default '0',
  `pols` int(10) NOT NULL default '0',
  `pols_cuentas` int(10) NOT NULL default '0',
  `transacciones` smallint(5) NOT NULL default '0',
  `hilos_msg` smallint(5) NOT NULL default '0',
  `pol_gobierno` int(10) NOT NULL default '0',
  `partidos` tinyint(3) NOT NULL default '0',
  `frase` smallint(5) NOT NULL default '0',
  `empresas` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_transacciones`
--

CREATE TABLE IF NOT EXISTS `pol_transacciones` (
  `ID` mediumint(8) NOT NULL auto_increment,
  `pols` int(10) NOT NULL default '0',
  `emisor_ID` mediumint(8) NOT NULL default '0',
  `receptor_ID` mediumint(8) NOT NULL default '0',
  `concepto` varchar(90) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=479 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pol_users`
--

CREATE TABLE IF NOT EXISTS `pol_users` (
  `ID` mediumint(8) NOT NULL default '0',
  `nick` varchar(14) NOT NULL default '',
  `pols` int(10) NOT NULL default '0',
  `fecha_registro` datetime NOT NULL default '0000-00-00 00:00:00',
  `fecha_last` datetime NOT NULL default '0000-00-00 00:00:00',
  `partido_afiliado` smallint(6) NOT NULL default '0',
  `estado` enum('turista','ciudadano','expulsado') NOT NULL default 'turista',
  `nivel` tinyint(3) NOT NULL default '1',
  `email` varchar(255) NOT NULL default '',
  `num_elec` tinyint(3) NOT NULL default '0',
  `online` int(10) NOT NULL default '0',
  `fecha_init` datetime NOT NULL default '0000-00-00 00:00:00',
  `ref` mediumint(8) NOT NULL default '0',
  `ref_num` tinyint(3) NOT NULL default '0',
  `api_pass` varchar(16) NOT NULL default '0',
  `api_num` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `nick` (`nick`),
  UNIQUE KEY `api_pass` (`api_pass`),
  KEY `estado` (`estado`),
  KEY `partido_afiliado` (`partido_afiliado`),
  KEY `nivel` (`nivel`),
  KEY `pols` (`pols`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
