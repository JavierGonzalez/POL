<?php 
include('inc-login.php');

/*
0 - Plaza
1 - Parlamento (Congreso)
2 - Comisaria
3 - Tribunales
*/

switch ($_GET['a']) {

case 'plaza':
	$pol['chat_id'] = 0;
	$pol['chat_nombre'] = 'Plaza de POL';
	$pol['chat_sql'] = 'plaza';
	break;

case 'parlamento':
	$pol['chat_id'] = 1;
	$pol['chat_nombre'] = 'Parlamento de los Diputados';
	$pol['chat_sql'] = 'congreso';
	break;

case 'comisaria':
	$pol['chat_id'] = 2;
	$pol['chat_nombre'] = 'Comisaria de POL';
	$pol['chat_sql'] = 'comisaria';
	break;

case 'tribunales':
	$pol['chat_id'] = 3;
	$pol['chat_nombre'] = 'Tribunales de POL';
	$pol['chat_sql'] = 'tribunales';
	break;


case 'gobierno':
	$pol['chat_id'] = 4;
	$pol['chat_nombre'] = 'Gobierno de POL';
	$pol['chat_sql'] = 'gobierno';
	break;

case 'hotel-arts':
	$pol['chat_id'] = 5;
	$pol['chat_nombre'] = 'Hotel Arts';
	$pol['chat_sql'] = 'arts';
	break;

default:
}

if ($_GET['a']) {

	include('inc-chat.php');
	$txt_title = 'CHAT: ' . $pol['chat_nombre'];
}


include('theme.php');
?>