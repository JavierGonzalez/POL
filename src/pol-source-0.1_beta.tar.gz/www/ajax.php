<?php
@include('/home/teoriza/public_html/_blogs/conectar-mysql.php'); 
$link = conectar();
header('connection: close');
header('Content-Type: text/plain');
ob_start('ob_gzhandler');

/*
m		msg
@		Policia
+		??
#		Sistema
_		null (nunca en sql)
*/

function chat_refresh($id, $n) {
	global $link;

	session_start();
	// $_SESSION['pol']['user_ID'];

	$t = '';
	$res = mysql_unbuffered_query("SELECT * FROM pol_chat_" . $id . " WHERE ID_msg > '" . $n . "' ORDER BY ID_msg DESC LIMIT 40", $link);
	while ($r = mysql_fetch_array($res)) { 
		if (($r['user_ID'] == 0) OR ($r['user_ID'] == $_SESSION['pol']['user_ID'])) {
			$t = $r['type'] . ' ' . $r['ID_msg'] . ' ' . substr($r['time'], 11, 5) . ' ' . $r['user'] . ' ' . $r['msg'] . "\n" . $t; 
		} else {
			$t = '_ ' . $r['ID_msg'] . "\n" . $t; 
		}
	}
	return $t;
}


$date = date('Y-m-d H:i:s');
$chat_id = $_GET['id'];

if ($_GET['a'] == 'enviar') {

	$nick = $_POST['nick'];
	$user_ID = $_POST['uid'];
	$msg = $_POST['msg'];
	$type = 'm';

	$result = mysql_unbuffered_query("
SELECT ID, nick, 
(SELECT ID FROM pol_estudios_users WHERE user_ID = pol_users.ID AND cargo = '1' AND (ID_estudio = '12' OR ID_estudio = '18') LIMIT 1) AS es_poli,
(SELECT ID FROM pol_estudios_users WHERE user_ID = pol_users.ID AND cargo = '1' AND (ID_estudio = '7' OR ID_estudio = '16' OR ID_estudio = '19') LIMIT 1) AS es_gobierno
FROM pol_users WHERE ID = '" . $user_ID . "' LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){ 
		$user_ID = $row['ID']; 
		$user_nick = $row['nick'];  
		if ($row['es_poli']) { $type = '@'; } 
		elseif ($row['es_gobierno']) { $type = '+'; }
	}

	$result = mysql_unbuffered_query("SELECT ID, expire FROM pol_ban WHERE user_ID = '" . $user_ID . "' LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){ $esta_baneado = $row['ID']; $expire = $row['expire']; }

	if ($expire < $date) { mysql_query("DELETE FROM pol_ban WHERE expire < '" . $date . "'", $link); }


	
	if ((strlen($msg) < 260) AND ($nick == $user_nick) AND ($user_ID) AND (!$esta_baneado)) {
		$msg = strip_tags($msg);
		$msg = trim($msg);
		$msg = str_replace("\n", "", $msg);
		$msg = str_replace("\r", "", $msg);
		if (substr($msg, 0, 1) == '/') {
			
			$msg_array = explode(" ", $msg);
			$msg_key = substr($msg_array[0], 1);
			$msg_rest = substr($msg, (strlen($msg_key) + 2));
			$user_ID_priv = '0';

			switch ($msg_key) {
				case 'dado':
					$elmsg = '<b>[#]</b> <em>' . $user_nick . '</em> tira el dado... <b>' . mt_rand(1,6) . '</b> &nbsp; <em>' . $msg_rest . '</em>';
					break;
				case 'me':
					$elmsg = '<b>[#]</b> <b>' . $user_nick . '</b> ' . $msg_rest . '</em>';
				case 'aleatorio':
					$elmsg = '<b>[#]</b> <b>' . $user_nick . '</b> aleatorio: <b>' . mt_rand(00000,99999) . '</b>';
					break;
				case 'msg':
					$nick_receptor = trim($msg_array[1]);
					$result = mysql_unbuffered_query("SELECT ID FROM pol_users WHERE nick = '" . $nick_receptor . "' LIMIT 1", $link);
					while($row = mysql_fetch_array($result)){ 
						$elmsg = '<b>[MSG] ' . $user_nick . '</b>: ' . substr($msg_rest, (strlen($nick_receptor)));
						$user_ID_priv = $row['ID'];
					}
					break;
			}

			if ($elmsg) { mysql_query("INSERT INTO pol_chat_" . $chat_id . " (user, time, msg, type, user_ID) VALUES ('" . $user_nick . "', '" . $date . "', '" . $elmsg . "', '#', '" . $user_ID_priv . "')", $link); }
			
		} else {
			$msg = ereg_replace("[[:alpha:]]+://[^<>[:space:]]+[[:alnum:]/]","<a target=\"_blank\" href=\"\\0\">\\0</a>", $msg);
			mysql_query("INSERT INTO pol_chat_" . $chat_id . " (user, time, msg, type) VALUES ('" . $user_nick . "', '" . $date . "', '" . $msg . "', '" . $type . "')", $link);
			mysql_query("UPDATE pol_users SET fecha_last = '" . $date . "' WHERE ID = '" . $user_ID . "' LIMIT 1");

			$time_margen = date('Y-m-d H:i:00', time() - 7200); //2h
			//mysql_query("DELETE FROM pol_chat_" . $chat_id . " WHERE time < '" . $time_margen . "'", $link);
		}
	}
	echo chat_refresh($_GET['id'], $_GET['n']);


} elseif (($_GET['n']) AND ($chat_id)) {
	echo chat_refresh($chat_id, $_GET['n']);
}

ob_end_flush();
mysql_close($link);
?>