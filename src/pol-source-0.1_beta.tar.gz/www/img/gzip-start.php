<?php 
$os = time() + 259200; //3dias
header('Expires: ' . gmdate('D, d M Y H:00:00', $os) . ' GMT');
header('Cache-Control: must-revalidate, max-age=' . $os);

$pi = pathinfo($_SERVER['PHP_SELF']);
switch ($pi['extension']) {
case 'css': header('Content-type: text/css'); break;
case 'js': header('Content-type: text/javascript'); break;
}

ob_start('ob_gzhandler');
?>
