<?php 
include('inc-login.php');

function gen_url($url) {
	$url = trim($url);
	$url = utf8_decode($url);
	$url = strtr($url, " ��������������", "-aeiouncaeiounc");
	$mal = array(',', '.', ':', ';', '�', '�', '!', '�', '?', '�', '%', '"', '&', '(', ')', '[', ']', '{', '}', '/', '\'', '`', '�');
	$ok	 = array('',  '',  '',  '', 'u', 'u',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '', '', '', '');
	$url = str_replace($mal, $ok, $url);
	$url = strip_tags($url);
	$url = strtolower($url);
	return $url;
}

function gen_text($text, $type='') {
	$text = utf8_decode($text);
	if ($type == 'plain') {
		$text = strip_tags($text);
		$text = nl2br($text);
		$text = ereg_replace("[[:alpha:]]+://[^<>[:space:]]+[[:alnum:]/]","<a href=\"\\0\">\\0</a>", $text);
	} else {
		$text = strip_tags($text, "<span>,<font>,<strong>,<p>,<b>,<em>,<ul>,<ol>,<li>,<blockquote>,<a>,<h2>,<h3>,<h4>,<br>,<hr>");
		$text = preg_replace('#(<[^>]+[\s\r\n\"\'])(on|xmlns)[^>]*>#iU', "$1>", $text); //prevent XSS
		$text = str_replace("\n\n", "<br /><br />\n\n", $text); //LINUX
		$text = str_replace("\r\n\r\n", "<br /><br />\r\n\r\n", $text); //WINDOWS
	}

	//acentos
	$mal =	array('�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�');
	$ok	 = array('&ordm;', '&ordf;', '&copy;', '&reg;', '&deg;', '&aacute;', '&eacute;', '&iacute;', '&oacute;', '&uacute;', '&Aacute;', '&Eacute;', '&Iacute;', '&Oacute;', '&Uacute;', '&ntilde;', '&Ntilde;', '&uuml;', '&Uuml;', '&iquest;');
	$text = str_replace($mal, $ok, $text);

	return $text;
}


if ($pol['user_ID']) {
switch ($_GET['a']) { //#####################################################


	case 'api':
		if (($pol['user_ID']) AND ($_GET['b'] == 'gen_pass')) {
			mysql_query("UPDATE pol_users SET api_pass = '" . substr(md5(mt_rand(1000000000,9999999999)), 0, 12) . "' WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			$refer_url = 'http://pol.teoriza.com/perfil/' . strtolower($pol['nick']) . '/';
		}
		break;

/*
pol_cat			(ID, url, nombre, time, num, nivel, tipo[empresas|docs|cargos])
pol_empresas	(ID, url, nombre, user_ID, descripcion, web, cat_ID, time)
*/
case 'empresa':

	if (($_GET['b'] == 'crear') AND ($pol['pols'] >= $pol['config']['pols_empresa']) AND (ctype_digit($_POST['cat'])) AND ($_POST['nombre'])) {

		$nombre = $_POST['nombre'];
		$url = gen_url($nombre);

		
		$result = mysql_query("SELECT ID, url FROM pol_cat WHERE ID = '" . $_POST['cat'] . "' LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $cat_url = $row['url']; $cat_ID = $row['ID']; }

		mysql_query("INSERT INTO pol_empresas (url, nombre, user_ID, descripcion, web, cat_ID, time) 
VALUES ('" . $url . "', '" . $nombre . "', '" . $pol['user_ID'] . "', 'Editar...', '', '" . $cat_ID . "', '" . $date . "')", $link);

		mysql_query("UPDATE pol_cat SET num = num + 1 WHERE ID = '" . $cat_ID . "' LIMIT 1", $link);

		pols_transferir($pol['config']['pols_empresa'], $pol['user_ID'], '-1', 'Creacion nueva empresa: ' . $nombre);

		$return = $cat_url . '/' . $url . '/';

	} elseif (($_GET['b'] == 'editar') AND ($_POST['txt'])) {

		$txt = gen_text($_POST['txt']);

		mysql_query("UPDATE pol_empresas SET descripcion = '" . $txt . "' WHERE ID = '" . $_GET['ID'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);

		$return =  $_POST['return'];
	}
	$refer_url = 'http://pol.teoriza.com/empresas/' . $return;
	break;



/*
pol_mercado	(ID, user_ID, title, descripcion, pols ,tipo, time, estado) 
pol_pujas		(ID, mercado_ID, user_ID, pols, time)
*/
case 'mercado':
	if (($_GET['b'] == 'puja') AND ($_GET['ID']) AND ($_POST['puja'] > 0) AND (ctype_digit($_POST['puja']))) {
		$ID = $_GET['ID'];
		$pols = $_POST['puja'];
		
		//puja valida
		$pols_max = true;
		$result = mysql_query("SELECT pols FROM pol_pujas 
WHERE mercado_ID = '" . $ID . "' 
ORDER BY pols DESC LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ if ($row['pols'] >= $pols) { $pols_max = false; } }

		if (($pols_max) AND ($pols <= $pol['pols'])) {
			mysql_query("INSERT INTO pol_pujas (mercado_ID, user_ID, pols, time) VALUES ('" . $ID . "', '" . $pol['user_ID'] . "', '" . $pols . "', '" . $date . "')", $link);
			evento_chat('<b>[POLs] Puja</b> por <em>frase</em>, ' . $pol['nick'] . ' por <a href="/mercado/frase/"><b>' . $pols . ' POLs</b></a>'); 
		}

		$refer_url = 'http://pol.teoriza.com/mercado/frase/';
	} elseif (($_GET['b'] == 'editarfrase') AND ($pol['config']['pols_fraseedit'] == $pol['user_ID'])) {

		$url = '<a href="http://' . strip_tags($_POST['url']) . '" rel="nofollow">' . ucfirst(strip_tags($_POST['frase'])) . '</a>';
		mysql_query("UPDATE pol_config SET valor = '" . $url . "' WHERE dato = 'pols_frase' LIMIT 1", $link);
		
		$refer_url = 'http://pol.teoriza.com/mercado/frase/editar/';
	}
	if (!$refer_url) { $refer_url = 'http://pol.teoriza.com/mercado/frase/'; }

	break;


case 'pols':
/*
pol_transacciones		(ID, pols, emisor_ID, receptor_ID, concepto, time)
pol_cuentas			(ID, nombre, user_ID, pols, nivel, time)
*/
	if ($pol['estado'] == 'ciudadano') {
		if (($_GET['b'] == 'transferir') AND (ctype_digit($_POST['pols'])) AND ($_POST['pols'] != 0) AND ($_POST['concepto'])) {

			$concepto = ucfirst(strip_tags($_POST['concepto']));
			$pols = $_POST['pols'];

			$origen = false;
			$destino = false;


			//ORIGEN
			if ($_POST['origen'] == '0') { 
				//Personal

				//tienes dinero suficiente y nick existe
				$result = mysql_query("SELECT ID FROM pol_users WHERE ID = '" . $pol['user_ID'] . "' AND pols >= '" . $pols . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $origen = 'ciudadano'; }

			} elseif (ctype_digit($_POST['origen'])) { 
				//Cuenta

				$result = mysql_query("SELECT ID FROM pol_cuentas WHERE ID = '" . $_POST['origen'] . "' AND pols >= '" . $pols . "' AND (user_ID = '" . $pol['nivel'] . "' OR '" . $pol['nivel'] . "' >= nivel) LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $origen = 'cuenta'; }

			}

			//DESTINO
			if (($_POST['destino'] == 'ciudadano') AND ($_POST['ciudadano'])) {
				//Ciudadano

				//nick existe
				$result = mysql_query("SELECT ID FROM pol_users WHERE nick = '" . $_POST['ciudadano'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $destino = 'ciudadano'; $destino_user_ID = $row['ID']; }

			} elseif (($_POST['destino'] == 'cuenta') AND ($_POST['cuenta'])) {
				//cuenta
				
				//cuenta existe
				$result = mysql_query("SELECT ID FROM pol_cuentas WHERE ID = '" . $_POST['cuenta'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $destino = 'cuenta'; $destino_cuenta_ID = $row['ID']; }
			}


			if (($origen) AND ($destino)) { //todo OK

				//quitar
				if ($origen == 'ciudadano') {
					mysql_query("UPDATE pol_users SET pols = pols - " . $pols . " WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
					$emisor_ID = $pol['user_ID'];
				} elseif ($origen == 'cuenta') {
					mysql_query("UPDATE pol_cuentas SET pols = pols - " . $pols . " WHERE ID = '" . $_POST['origen'] . "' LIMIT 1", $link);
					$emisor_ID = '-' . $_POST['origen'];
				}

				//ingresar
				if ($destino == 'ciudadano') {
					mysql_query("UPDATE pol_users SET pols = pols + " . $pols . " WHERE ID = '" . $destino_user_ID . "' LIMIT 1", $link);
					$receptor_ID = $destino_user_ID;
				} elseif ($destino == 'cuenta') {
					mysql_query("UPDATE pol_cuentas SET pols = pols + " . $pols . " WHERE ID = '" . $destino_cuenta_ID . "' LIMIT 1", $link);
					$receptor_ID = '-' . $destino_cuenta_ID;
				}


				mysql_query("INSERT INTO pol_transacciones (pols, emisor_ID, receptor_ID, concepto, time) VALUES ('" . $pols . "', '" . $emisor_ID . "', '" . $receptor_ID . "', '" . $concepto . "', '" . $date . "')", $link);
			}





		} elseif (($_GET['b'] == 'crear-cuenta') AND ($_POST['nombre']) AND ($pol['pols'] >= $pol['config']['pols_cuentas'])) {
			$_POST['nombre'] = ucfirst(strip_tags($_POST['nombre']));

			pols_transferir($pol['config']['pols_cuentas'], $pol['user_ID'], '-1', 'Creacion nueva cuenta bancaria: ' . $_POST['nombre']);
			mysql_query("INSERT INTO pol_cuentas (nombre, user_ID, pols, nivel, time) VALUES ('" . $_POST['nombre'] . "', '" . $pol['user_ID'] . "', 0, 0, '" . $date . "')", $link);

			$refer_url = 'http://pol.teoriza.com/pols/cuentas/';
		} elseif (($_GET['b'] == 'eliminar-cuenta') AND ($_GET['ID'])) {
			mysql_query("DELETE FROM pol_cuentas WHERE ID = '" . $_GET['ID'] . "' AND pols = '0' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			$refer_url = 'http://pol.teoriza.com/pols/cuentas/';
		}
	}
	if (!$refer_url) { $refer_url = 'http://pol.teoriza.com/pols/'; }

	break;


case 'referendum':

	if ($_GET['b'] == 'crear') {
		if ((($pol['nivel'] >= 50) AND ($_POST['tipo'] == 'sondeo')) OR (($pol['nivel'] >= 95) AND ($_POST['tipo'] != 'sondeo'))) { 


			for ($i=0;$i<10;$i++) {
				if ($_POST['respuesta' . $i]) { $respuestas .= trim($_POST['respuesta' . $i]) . '|'; }
			}

			$time_expire = date('Y-m-d H:i:s', time() + $_POST['time_expire']);
			$_POST['pregunta'] = strip_tags($_POST['pregunta']);
			$_POST['descripcion'] = gen_text($_POST['descripcion']);
			mysql_query("INSERT INTO pol_ref (pregunta, descripcion, respuestas, time, time_expire, user_ID, estado, tipo) VALUES ('" . $_POST['pregunta'] . "', '" . $_POST['descripcion'] . "', '" . $respuestas . "', '" . $date . "', '" . $time_expire . "', '" . $pol['user_ID'] . "', 'ok', '" . $_POST['tipo'] . "')", $link);

			$result = mysql_unbuffered_query("SELECT ID FROM pol_ref WHERE user_ID = '" . $pol['user_ID'] . "' ORDER BY ID DESC LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $ref_ID = $row['ID']; }
			evento_chat('<b>[' . strtoupper($_POST['tipo']) . ']</b> Creado por ' . $pol['nick'] . ': <a href="/referendum/' . $ref_ID . '/"><b>' . $_POST['pregunta'] . '</b></a> <span style="color:grey;">(' . duracion($_POST['time_expire']) . ')</span>');
		}
	} elseif (($_GET['b'] == 'votar') AND ($_POST['voto'] != null) AND ($_POST['ref_ID'])) { 

			$result = mysql_unbuffered_query("SELECT tipo, pregunta FROM pol_ref WHERE ID = '" . $_POST['ref_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $tipo = $row['tipo']; $pregunta = $row['pregunta']; }

			$result = mysql_unbuffered_query("SELECT ID FROM pol_estudios_users WHERE user_ID = '" . $pol['user_ID'] . "' AND cargo = '1' AND ID_estudio = '6' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $es_diputado = true; }

			if (($tipo == 'sondeo') OR ($tipo == 'referendum') OR (($tipo == 'parlamento') AND ($es_diputado))) {
				$result = mysql_unbuffered_query("SELECT ID FROM pol_ref_votos WHERE user_ID = '" . $pol['user_ID'] . "' AND ref_ID = '" . $_POST['ref_ID'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $ha_votado = true; }

				if (!$ha_votado) {
					mysql_query("INSERT INTO pol_ref_votos (user_ID, ref_ID, voto) VALUES ('" . $pol['user_ID'] . "', '" . $_POST['ref_ID'] . "', '" . $_POST['voto'] . "')", $link);
					mysql_query("UPDATE pol_ref SET num = num +1 WHERE ID = '" . $_POST['ref_ID'] . "' LIMIT 1", $link);

					evento_chat('<b>[' . strtoupper($tipo) . ']</b> Voto de  ' . $pol['nick'] . ' en: <a href="/referendum/' . $_POST['ref_ID'] . '/">' . $pregunta . '</a>');
				}
			}

	} elseif (($_GET['b'] == 'eliminar') AND ($_GET['ID'])) { 
		mysql_query("DELETE FROM pol_ref WHERE ID = '" . $_GET['ID'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
		mysql_query("DELETE FROM pol_ref_votos WHERE ref_ID = '" . $_GET['ID'] . "'", $link);
	}

	$refer_url = 'http://pol.teoriza.com/referendum/';
	break;

case 'foro':

	if ($pol['estado'] == 'ciudadano') { 
		if (($_POST['text']) AND ($_POST['subforo'])) {
			$text = gen_text($_POST['text'], 'plain');
			$time = $date;
			if (($_GET['b'] == 'hilo') AND ($_POST['title'])) {
				$title = strip_tags($_POST['title']);
				$url = gen_url($title);
				mysql_query("INSERT INTO pol_foros_hilos (sub_ID, url, user_ID, title, time, time_last, text, cargo) VALUES ('" . $_POST['subforo'] . "', '" . $url . "', '" . $pol['user_ID'] . "', '" . $title . "', '" . $time . "', '" . $time . "', '" . $text . "', '" . $_POST['encalidad'] . "')", $link);
				evento_chat('<b>[FORO]</b> Nuevo hilo de ' . $pol['nick'] . ': <a href="' . $_POST['return_url'] . $url . '/"><b>' . $title . '</b></a> <span style="color:grey;">(1)</span>');

			} elseif ($_GET['b'] == 'reply') {
				mysql_query("INSERT INTO pol_foros_msg (hilo_ID, user_ID, time, text, cargo) VALUES ('" . $_POST['hilo'] . "', '" . $pol['user_ID'] . "', '" . $time . "', '" . $text . "', '" . $_POST['encalidad'] . "')", $link);
				mysql_query("UPDATE pol_foros_hilos SET num = num +1, time_last = '" . $time . "' WHERE ID = '" . $_POST['hilo'] . "' LIMIT 1", $link);

				$result = mysql_unbuffered_query("SELECT title, num FROM pol_foros_hilos WHERE ID = '" . $_POST['hilo'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)) { $title = $row['title']; $num = $row['num']; }
				evento_chat('<b>[FORO]</b> Nuevo mensaje de ' . $pol['nick'] . ': <a href="' . $_POST['return_url'] . '">' . $title . '</a> <span style="color:grey;">(' . $num . ')</span>');
				
			}
			$refer_url = 'http://pol.teoriza.com' . $_POST['return_url'];
		}
		if (($_GET['b'] == 'eliminarhilo') AND ($_GET['ID'])) {
			$result = mysql_unbuffered_query("SELECT ID FROM pol_foros_hilos WHERE ID = '" . $_GET['ID'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $es_ok = true; }
			if ($es_ok) {
				mysql_query("DELETE FROM pol_foros_hilos WHERE ID = '" . $_GET['ID'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
				mysql_query("DELETE FROM pol_foros_msg WHERE hilo_ID = '" . $_GET['ID'] . "'", $link);
			}
			$refer_url = 'http://pol.teoriza.com/foro/';

		} elseif (($_GET['b'] == 'eliminarreply') AND ($_GET['hilo_ID']) AND ($_GET['ID'])) {

			$result = mysql_unbuffered_query("SELECT ID FROM pol_foros_msg WHERE ID = '" . $_GET['ID'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $es_ok = true; }
			if ($es_ok) {
				mysql_query("DELETE FROM pol_foros_msg WHERE ID = '" . $_GET['ID'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
				mysql_query("UPDATE pol_foros_hilos SET num = num-1 WHERE ID = '" . $_GET['hilo_ID'] . "' LIMIT 1", $link);
			}
			$refer_url = 'http://pol.teoriza.com/foro/';

		} elseif (($_GET['b'] == 'editar') AND ($_POST['text']) AND ($_POST['subforo'])) {
			$text = gen_text($_POST['text'], 'plain');
			if ($_POST['hilo']) { //msg
				mysql_query("UPDATE pol_foros_msg SET text = '" . $text . "', cargo = '" . $_POST['encalidad'] . "' WHERE ID = '" . $_POST['hilo'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			} else { //hilo
				mysql_query("UPDATE pol_foros_hilos SET text = '" . $text . "', cargo = '" . $_POST['encalidad'] . "' WHERE ID = '" . $_POST['subforo'] . "' AND user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			}
		}

	}

	break;


	case 'expulsar':
		if (($pol['estado'] == 'ciudadano') AND ($_POST['user_ID'])) {


			$result = mysql_query("SELECT ID, nick FROM pol_users WHERE ID = '" . $_POST['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $kick_user_ID = $row['ID']; $kick_nick = $row['nick']; }

			$result = mysql_unbuffered_query("SELECT ID FROM pol_estudios_users WHERE user_ID = '" . $pol['user_ID'] . "' AND cargo = '1'  AND (ID_estudio = '12' OR ID_estudio = '18' OR ID_estudio = '13') LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $es_poli = true; }


			if (($es_poli) AND ($kick_user_ID)) {
				$expire = date('Y-m-d H:i:s', time() + $_POST['expire']);
				mysql_query("INSERT INTO pol_ban (user_ID, autor, expire, razon) VALUES ('" . $kick_user_ID . "', '" . $pol['user_ID'] . "', '" . $expire . "', '" . $_POST['razon'] . "')", $link);
				evento_chat('<b>[KICK]</b> El Ciudadano <b>' . $kick_nick . '</b> ha sido expulsado durante <b>' . duracion($_POST['expire']) . '</b> por <b>' . $pol['nick'] . '</b>, razon: <em>' . $_POST['razon'] . '</em>');
			}


			$refer_url = 'http://pol.teoriza.com/form/expulsar/';
		}
		break;

	case 'mensaje-leido':
		if (($pol['estado'] == 'ciudadano') AND ($_GET['ID'])) {
			mysql_query("UPDATE pol_mensajes SET leido = '1' WHERE ID = '" . $_GET['ID'] . "' AND recibe_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			$refer_url = 'http://pol.teoriza.com/msg/';
		}
		break;

	case 'borrar-mensaje':
		if (($pol['estado'] == 'ciudadano') AND ($_GET['ID'])) {
			mysql_query("DELETE FROM pol_mensajes WHERE ID = '" . $_GET['ID'] . "' AND recibe_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			$refer_url = 'http://pol.teoriza.com/msg/';
		}
		break;

	case 'enviar-mensaje':
			
		if (($pol['estado'] == 'ciudadano') AND (!$_GET['b']) AND ($_POST['text']) AND ($_POST['para'])) {

			$text = $_POST['text'];
			$text = gen_text($text, 'plain');
			$time = $date;

			$asunto = '[POL] Tienes un mensaje urgente de ' . $pol['nick'];
			$mensaje = 'Hola Ciudadano,<br /><br />Has recibido un mensaje urgente enviado por el Ciudadano: ' . $pol['nick'] . '.<br /><br />Para leerlo has de entrar aqu�: <a href="http://pol.teoriza.com/msg/">http://pol.teoriza.com/msg/</a><br /><br />Mensaje de ' . $pol['nick'] . ':<hr />' . $text . '<hr /><br /><br />Nota: Si este aviso te ha resultado molesto puedes defender tu derecho apoyandote en la Justicia de POL.<br /><br /><br />POL<br />http://pol.teoriza.com';

			if (($_POST['para'] == 'ciudadano') AND ($_POST['nick'])) {

				$result = mysql_query("SELECT ID FROM pol_users WHERE nick = '" . $_POST['nick'] . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ 
					mysql_query("INSERT INTO pol_mensajes (envia_ID, recibe_ID, time, text, leido, cargo) VALUES ('" . $pol['user_ID'] . "', '" . $row['ID'] . "', '" . $time . "', '" . $text . "', '0', '" . $_POST['calidad'] . "')", $link);
					if ($_POST['urgente'] == '1') { enviar_email($row['ID'], $asunto, $mensaje); }
					evento_chat('<b>[MP] Nuevo mensaje</b> de <em>' . $pol['nick'] . '</em> (<a href="/msg/"><b>Leer!</b></a>)', $row['ID']); 
				}
			} elseif (($_POST['para'] == 'cargo') AND ($_POST['cargo_ID'])) {
				$result = mysql_query("SELECT user_ID 
FROM pol_estudios_users 
WHERE cargo = '1'
AND estado = 'ok'
AND ID_estudio = '" . $_POST['cargo_ID'] . "' LIMIT 50", $link);
				while($row = mysql_fetch_array($result)){ 
					mysql_query("INSERT INTO pol_mensajes (envia_ID, recibe_ID, time, text, leido, cargo) VALUES ('" . $pol['user_ID'] . "', '" . $row['user_ID'] . "', '" . $time . "', '" . $text . "', '0', '" . $_POST['calidad'] . "')", $link);
					if ($_POST['urgente'] == '1') { enviar_email($row['user_ID'], $asunto, $mensaje); }
				}
			}




		}
		$refer_url = 'http://pol.teoriza.com/msg/';

		break;


	case 'elecciones-generales':

		$ID_partido = $_POST['ID_partido'];
		if (($pol['estado'] == 'ciudadano') AND (!$_GET['b']) AND ($ID_partido != null)) {

			$fecha_24_antes = date('Y-m-d H:i:00', strtotime($pol['config']['elecciones_inicio']) - $pol['config']['elecciones_antiguedad']);

			//fecha registro?
			$result = mysql_query("SELECT fecha_registro FROM pol_users WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $fecha_registro = $row['fecha_registro']; }

			//ha votado?
			$result = mysql_query("SELECT ID FROM pol_elecciones WHERE user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $ha_votado = $row['ID']; }
			
			if ((!$ha_votado) AND ($fecha_registro < $fecha_24_antes)) {
/*
pol_elecciones (ID, ID_partido, user_ID, nav, IP, time)
*/
				$nav = $_SERVER['HTTP_USER_AGENT'];
				$IP = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
				$time = $date;

				if ($ID_partido == '0') { //BLANCO
					mysql_query("INSERT INTO pol_elecciones (ID_partido, user_ID, nav, IP, time) VALUES ('0', '" . $pol['user_ID'] . "', '" . $nav . "', '" . $IP . "', '" . $time . "')", $link);
						$result = mysql_query("SELECT user_ID FROM pol_elecciones", $link);
						mysql_query("UPDATE pol_users SET num_elec = num_elec + 1 WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
				} else {
					$result = mysql_query("SELECT ID, 
(SELECT COUNT(ID) FROM pol_partidos_listas WHERE ID_partido = pol_partidos.ID LIMIT 1) AS num_lista
FROM pol_partidos 
WHERE estado = 'ok' 
AND ID = '" . $ID_partido . "'
AND fecha_creacion < '" . $fecha_24_antes . "'
LIMIT 1", $link);
					while($row = mysql_fetch_array($result)){
						mysql_query("INSERT INTO pol_elecciones (ID_partido, user_ID, nav, IP, time) VALUES ('" . $ID_partido . "', '" . $pol['user_ID'] . "', '" . $nav . "', '" . $IP . "', '" . $time . "')", $link);
						mysql_query("UPDATE pol_users SET num_elec = num_elec + 1 WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
					}
				}
			}

		}
		$refer_url = 'http://pol.teoriza.com/info/elecciones-generales/';
		
		break;

	case 'partido-lista':
		$b = $_GET['b'];
		$ID_partido = $_GET['ID'];

		if (($pol['estado'] == 'ciudadano') AND ($b) AND ($ID_partido)) {

			$result = mysql_query("SELECT ID_presidente, siglas FROM pol_partidos WHERE ID = '" . $ID_partido . "' AND ID_presidente = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){
				$siglas = $row['siglas'];


				if ($b == 'edit') {
					mysql_query("UPDATE pol_partidos SET descripcion = '" . gen_text($_POST['text']) . "' WHERE ID = '" . $ID_partido . "' LIMIT 1", $link);
				} elseif (($b == 'add') AND ($pol['config']['elecciones_estado'] != 'elecciones')) {
					mysql_query("INSERT INTO pol_partidos_listas (ID_partido, user_ID) VALUES ('" . $ID_partido . "', '" . $_POST['user_ID'] . "')", $link);
				} elseif (($b == 'del') AND ($pol['config']['elecciones_estado'] != 'elecciones')) {
					mysql_query("DELETE FROM pol_partidos_listas WHERE user_ID = '" . $_POST['user_ID'] . "' AND ID_partido = '" . $ID_partido . "' LIMIT 1", $link);
				} elseif (($b == 'ceder-presidencia') AND ($pol['config']['elecciones_estado'] != 'elecciones')) {
					mysql_query("UPDATE pol_partidos SET ID_presidente = '" . $_POST['user_ID'] . "' WHERE ID = '" . $ID_partido . "' LIMIT 1", $link);
					//faltan movidas, consolidar! (el cargo, en config..)
				}
				$refer_url = 'http://pol.teoriza.com/partidos/' . strtolower($siglas) . '/editar/';
			}
		}
		break;





	case 'cargo':
		$b = $_GET['b'];
		$cargo_ID = $_GET['ID'];

		if (($pol['estado'] == 'ciudadano') AND ($b) AND ($cargo_ID)) {
			$result = mysql_query("SELECT nivel FROM pol_estudios WHERE ID = '" . $cargo_ID . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){
				if ($pol['nivel'] >= $row['nivel']) {
					if ($b == 'edit') {
						mysql_query("UPDATE pol_estudios SET num_cargo = '" . $_POST['plazas'] . "', tiempo = '" . $_POST['tiempo'] . "', salario = '" . $_POST['salario'] . "' WHERE ID = '" . $cargo_ID . "' LIMIT 1", $link);
					} 
					elseif ($b == 'add') { cargo_add($cargo_ID, $_POST['user_ID']); }
					elseif ($b == 'del') { cargo_del($cargo_ID, $_POST['user_ID']); }
					$refer_url = 'http://pol.teoriza.com/cargos/' . $cargo_ID . '/';
				}
			}
		}

		break;

	case 'eliminar-partido':
		if (($pol['estado'] == 'ciudadano') AND ($pol['config']['elecciones_estado'] != 'elecciones')) {
			$result = mysql_query("SELECT ID FROM pol_partidos WHERE ID_presidente = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){
				mysql_query("DELETE FROM pol_partidos WHERE ID = '" . $row['ID'] . "' LIMIT 1", $link);
				mysql_query("DELETE FROM pol_partidos_listas WHERE ID_partido = '" . $row['ID'] . "' LIMIT 1", $link);
				evento_log(5, $row['ID']);
			}
		}
		$refer_url = 'http://pol.teoriza.com/partidos/';
		break;

	case 'eliminar-documento':
		if ($pol['estado'] == 'ciudadano') {
			mysql_query("UPDATE pol_docs SET estado = 'del' WHERE url = '" . $_GET['url'] . "' AND nivel <= '" . $pol['nivel'] . "' LIMIT 1", $link);
			evento_log(8, $_GET['url']);
		}
		$refer_url = 'http://pol.teoriza.com/doc/';
		break;


	case 'editar-documento':
		if (($pol['estado'] == 'ciudadano') AND ($_POST['text']) AND ($_POST['nivel'] <= 120)) {
			$text = gen_text($_POST['text']);
			$text = str_replace("../../", "/doc/", $text);


			mysql_query("UPDATE pol_docs SET user_ID = '" . $pol['user_ID'] . "', nivel = '" . $_POST['nivel'] . "', text = '" . $text . "', time_last = '" . $date . "' WHERE url = '" . $_POST['url'] . "' AND nivel <= '" . $pol['nivel'] . "' LIMIT 1", $link);
			evento_log(7, $_GET['ID']);
		}
		$refer_url = 'http://pol.teoriza.com/doc/' . $url . '/';
		break;

	case 'crear-documento':
		if (($pol['estado'] == 'ciudadano') AND (strlen($_POST['title']) > 5) AND (strlen($_POST['title']) < 200) AND ($_POST['text']) AND ($_POST['nivel'] <= 120)) {


			$url = gen_url($_POST['title']);
			$text = gen_text($_POST['text']);

			mysql_query("INSERT INTO pol_docs 
(user_ID, url, title, text, time, time_last, nivel, estado) 
VALUES ('" . $pol['user_ID'] . "', '" . $url . "', '" . $_POST['title'] . "', '" . $text . "', '" . $date . "', '" . $date . "', " . $_POST['nivel'] . ", 'ok')", $link);
			evento_log(6, $url);
		}
		$refer_url = 'http://pol.teoriza.com/doc/' . $url . '/';
		break;


	case 'afiliarse':
		if (($pol['estado'] == 'ciudadano') AND ($pol['config']['elecciones_estado'] != 'elecciones')) {
			mysql_query("UPDATE pol_users SET partido_afiliado = '" . $_POST['partido'] . "' WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			mysql_query("DELETE FROM pol_partidos_listas WHERE user_ID = '" . $pol['user_ID'] . "'", $link);
			evento_log(9, $_POST['partido']);
		}
		$refer_url = 'http://pol.teoriza.com/perfil/' . strtolower($pol['nick']) . '/';
		break;

	case 'crear-partido':
		$_POST['siglas'] = preg_replace("/[^[a-z]/i", "", $_POST['siglas']);

		if (($pol['estado'] == 'ciudadano') AND ($pol['config']['elecciones_estado'] != 'elecciones') AND (strlen($_POST['siglas']) <= 6) AND (strlen($_POST['siglas']) >= 2) AND ($_POST['nombre'])) {

			$_POST['descripcion'] = gen_text($_POST['descripcion']);

			mysql_query("INSERT INTO pol_partidos 
(ID_presidente, fecha_creacion, siglas, nombre, descripcion, estado) 
VALUES ('" . $pol['user_ID'] . "', '" . $date . "', '" . strtoupper($_POST['siglas']) . "', '" . $_POST['nombre'] . "', '" . $_POST['descripcion'] . "', 'ok')
", $link);
			evento_log(3, $_POST['siglas']);
		}
		$refer_url = 'http://pol.teoriza.com/partidos/';
		break;


	case 'solicitar-ciudadania':
		if (($pol['nick']) AND (!$pol['estado']) AND ($_POST['user_ID'] == $pol['user_ID'])) { //login ok, turista no

			$result = mysql_unbuffered_query("SELECT user_email FROM teoriza_users WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
			while($row = mysql_fetch_array($result)){ $email = $row['user_email']; }
			if ($email) {
		
				//Obtiene config: pols_afiliacion
				$result = mysql_query("SELECT valor FROM pol_config WHERE dato = 'pols_afiliacion' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ if ($row['pols'] >= $pols) { $pols_afiliacion = $row['valor']; } }

				//Si existe referencia IP, paga
				$IP = ip2long(isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
				$afiliacion = 0;
				$result = mysql_query("SELECT ID, user_ID,
(SELECT nick FROM pol_users WHERE ID = pol_referencias.user_ID LIMIT 1) AS nick
FROM pol_referencias WHERE IP = '" . $IP . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ 
					$afiliacion = $row['user_ID'];
					$ref = ' (ref: ' . crear_link($row['nick']) . ', gana ' . $pols_afiliacion . ' POLs)';
					pols_transferir($pols_afiliacion, '-1', $row['user_ID'], 'Referencia del Ciudadano: ' . $pol['nick']);
					mysql_query("UPDATE pol_users SET ref_num = ref_num + 1 WHERE ID = '" . $row['user_ID'] . "' LIMIT 1", $link);
				}

				
				$api_pass = substr(md5(mt_rand(1000000000,9999999999)), 0, 12);
				//crea el ciudadano
				mysql_query("INSERT INTO pol_users 
(ID, nick, pols, fecha_registro, fecha_last, partido_afiliado, estado, nivel, email, num_elec, online, fecha_init, ref, ref_num, api_pass, api_num) 
VALUES ('" . $pol['user_ID'] . "', '" . $pol['nick'] . "', '0', '" . $date . "', '" . $date . "', '', 'turista', '1', '" . $email . "', '0', '0', '" . $date . "', '" . $afiliacion . "', '0', '" . $api_pass . "', '0')", $link);

				evento_log(1);
				evento_chat('<b>[NUEVO]</b> Nuevo Ciudadano: <b>' . crear_link($pol['nick']) . '</b>' . $ref);
			}
			session_unset();
			session_destroy();
		}
		break;

		case 'logout':
			$refer_url = 'http://www.teoriza.com/registrar/login.php?a=logout';
			session_unset();
			session_destroy();
			break;



		case 'estudiar':

			if ($_GET['id']) {

				$result = mysql_query("SELECT ID
FROM pol_estudios_users
WHERE user_ID = '" . $pol['user_ID'] . "' AND estado = 'estudiando'
limit 1", $link);
				while($row = mysql_fetch_array($result)){ $c = true; }
				if ($c == false) {
					mysql_query("INSERT INTO pol_estudios_users 
(ID_estudio, user_ID, time, estado) 
VALUES ('" . $_GET['id'] . "', '" . $pol['user_ID'] . "', '" . $date . "', 'estudiando')
", $link);
					evento_log(10, $_GET['id']);
				}
			}

			$refer_url = 'http://pol.teoriza.com/estudios/';
			break;
}
}

include('cron-accion.php');
if ($link) { mysql_close($link); }
if (!$refer_url) { $refer_url = 'http://pol.teoriza.com/'; }

header('Location: ' . $refer_url);
?>