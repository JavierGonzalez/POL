<?php
//INIT MICROTIME
$mtime = explode(' ', microtime()); 
$tiempoinicial = $mtime[1] + $mtime[0]; 

include('inc-functions.php');
$date = date('Y-m-d H:i:s');


/* LOGIN START

	Sistema de Login de Blogs Teoriza. (desde LOGIN START hasta LOGIN END)

Este sistema de login funciona guardando el usuario (nick) y la contrase�a (un md5 de un md5) en cookies de cara al usuario, y de cara al servidor los datos son almacenados en una tabla MySQL independiente al resto de POL. 

Esta parte est� adaptada al sistema de usuarios de Blogs Teoriza, cuya tabla de usuarios completa es independiente de las de POL.

Por lo tanto para crear un POL nuevo debe crearse el sistema de usuarios. Esto se puede hacer tan solo modificando este trozo de c�digo (y una linea en accion.php en la acci�n "solicitar-ciudadania").

Para que el resto del c�digo de POL funcione, se debe definir estas dos variables de forma INEQUIVOCA, verificando la contrase�a md5.

$_SESSION['pol']['nick'] =  NICK;
$_SESSION['pol']['user_ID'] = user_ID;

 */

@include('/home/teoriza/public_html/_blogs/conectar-mysql.php');
$link = conectar('com');

if ($_COOKIE['teorizauser']) {
	session_start();
	if (!isset($_SESSION['pol'])) { //NO existe sesion
		$result = mysql_query("SELECT ID, user_pass, user_nicename FROM teoriza_users WHERE user_login = '"  . trim($_COOKIE['teorizauser']) . "' LIMIT 1", $link);
		while ($row = mysql_fetch_array($result)) { 
			if (md5($row['user_pass']) == trim($_COOKIE['teorizapass'])) { //pass OK
				$IP = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
				mysql_query("UPDATE teoriza_users SET last_time = '" . $date . "', IP = '" . ip2long($IP) . "', url_last = '" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "' WHERE ID = '" . $row['ID'] . "' LIMIT 1");
				$session_new = true;
				$_SESSION['pol']['nick'] =  $row['user_nicename'];
				$_SESSION['pol']['user_ID'] = $row['ID'];
			}
		}  
	}
}


/* LOGIN END */





if ($_SESSION['pol']['nick']) { //login OK

	$result = mysql_query("SELECT estado, pols, partido_afiliado, fecha_last, fecha_registro, nivel, fecha_init  FROM pol_users WHERE ID = '"  . $_SESSION['pol']['user_ID'] . "' LIMIT 1", $link);
	while ($row = mysql_fetch_array($result)) {
		if ($row['estado']) {
			$_SESSION['pol']['pols'] = $row['pols'];
			$_SESSION['pol']['estado'] = $row['estado'];
			$_SESSION['pol']['partido'] = $row['partido_afiliado'];
			$_SESSION['pol']['fecha_registro'] = $row['fecha_registro'];
			$_SESSION['pol']['nivel'] = $row['nivel'];
			$fecha_init = $row['fecha_init'];
			$fecha_last = $row['fecha_last'];
		}
	}


	if ($session_new) { //Nueva sesion, desde el [24 sep 22:22]
		$update = ", fecha_init = '" . $date . "'";

		if ($fecha_init != '0000-00-00 00:00:00') {
			$session_time = strtotime($fecha_last) - strtotime($fecha_init);
			$update .= ", online = online + " . $session_time;
		}
	}
	mysql_query("UPDATE pol_users SET fecha_last = '" . $date . "'" . $update . " WHERE ID = '" . $_SESSION['pol']['user_ID'] . "' LIMIT 1");


	$result = mysql_query("SELECT valor, dato FROM pol_config WHERE autoload = 'si'", $link);
	while ($row = mysql_fetch_array($result)) { $_SESSION['pol']['config'][$row['dato']] = $row['valor']; }

	$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_mensajes WHERE recibe_ID = '" . $_SESSION['pol']['user_ID'] . "' AND leido = '0'", $link);
	while($row = mysql_fetch_array($result)) { $_SESSION['pol']['msg'] = $row['num'];  }


	if ($_SESSION['pol']['estado'] == 'turista') { // TURISTA

		$time_margen = time() - $_SESSION['pol']['config']['tiempo_turista'];
		$fecha_registro = strtotime($_SESSION['pol']['fecha_registro']);

		if ($fecha_registro < $time_margen) { //ciudadanizar!
			mysql_query("UPDATE pol_users SET estado = 'ciudadano' WHERE ID = '" . $_SESSION['pol']['user_ID'] . "' LIMIT 1");
			$_SESSION['pol']['estado'] = 'ciudadano';
			evento_log(2, '', '', $_SESSION['pol']['nick']);
		} else { //turista, queda X horas...
			$_SESSION['pol']['tiempo_ciudadanizacion'] = '<b>' . round((($fecha_registro - $time_margen) / 60) / 60, 1) . ' horas</b> para ser ciudadano'; 
		}



	} elseif ($_SESSION['pol']['estado'] == 'ciudadano') { // CIUDADANO
		$result = mysql_query("SELECT ID_estudio, time, 
(SELECT tiempo FROM pol_estudios WHERE ID = pol_estudios_users.ID_estudio LIMIT 1) AS tiempo
FROM pol_estudios_users
WHERE estado = 'estudiando' AND user_ID = '" . $_SESSION['pol']['user_ID'] . "'
LIMIT 1", $link);
		while ($row = mysql_fetch_array($result)) { 
			$ID_estudio = $row['ID_estudio']; 
			$t_estudiado = strtotime($row['time']) + $row['tiempo'];
			if (($ID_estudio) AND (time() >= $t_estudiado)) { //Estudio acabado
				mysql_query("UPDATE pol_estudios_users SET estado = 'ok' WHERE ID_estudio = '" . $row['ID_estudio'] . "' AND user_ID = '" . $_SESSION['pol']['user_ID'] . "' LIMIT 1");
			}
		}
		
	}
} else {
	$result = mysql_query("SELECT valor, dato FROM pol_config WHERE autoload = 'si'", $link);
	while ($row = mysql_fetch_array($result)) { $_SESSION['pol']['config'][$row['dato']] = $row['valor']; }
}


$pol = $_SESSION['pol'];

include('inc-elecciones.php');
?>