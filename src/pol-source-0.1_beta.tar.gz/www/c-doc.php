<?php 
include('inc-login.php');

if ($_GET['a']) {

	$result = mysql_query("SELECT 
ID, user_ID, url, title, text, time, nivel, time_last 
FROM pol_docs
WHERE url = '" . trim($_GET['a']) . "'
LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){

		if (($_GET['b'] == 'editar') AND ($pol['nivel'] >= $row['nivel'])) { //EDITAR!

			$text = $row['text'];

			/*
			$text = str_replace("<br /><br />", "", $row['text']);
			$text = str_replace("&lt;", "&amp;lt;", $text);
			$text = str_replace("&gt;", "&amp;gt;", $text);
			*/
			
			$confirm_salir = ' onClick="if (!confirm(\'&iquest;Seguro que quieres salir? No se guardar&aacute;n los cambios.\')) { return false; }"';

			$txt .= '<h1><img src="/img/doc-edit.gif" alt="Editar Documento" /> ' . $row['title'] . '</h1>
<form action="/accion.php?a=editar-documento&ID=' . $row['ID'] . '" method="post">
<input type="hidden" name="url" value="' . $row['url'] . '"  />

<p>Nivel de acceso: <b>' . $row['nivel'] . '</b><br />
' . form_select_nivel($row['nivel']) . ' (nivel minimo requerido para editar este documento)</p>

<p>' . editor_enriquecido('text', $text) . '</p>

<p><input type="submit" value="Guardar" /> (<a href="/doc/' .$row['url'] . '/"' . $confirm_salir . '>Ver documento</a>)</form></p>';

		} else { 

			$txt .= '<h1><img src="/img/doc.gif" alt="Documento" /> ' . $row['title'] . '</h1><div style="text-align:justify;margin:20px;">' . $row['text'] . '</div><br /><br /><hr style="width:100%;" />'; 

			if ($pol['nivel'] >= $row['nivel']) { 
				if (($pol['nivel'] >= 50) OR ($pol['user_ID'] == $row['user_ID'])) {
					$txt .= '<span style="float:right;"><form><input type="button" value="Eliminar" onClick="if (!confirm(\'&iquest;Estas convencido de que quieres ELIMINAR para siempre este Documento?\')) { return false; } else { window.location.href=\'/accion.php?a=eliminar-documento&url=' . $row['url'] . '\'; }"></form></span>';
				}
				$txt .= '<span><form><input type="button" value="Editar" onclick="window.location.href=\'/doc/' . $row['url'] . '/editar/\'"> Creado el <em>' . explodear(' ',$row['time'], 0) . '</em>, &uacute;ltima edici&oacute;n hace <em>' . duracion(time() - strtotime($row['time_last'])) . '</em>.</form></span>';
			} else { $txt .= '<span style="float:right;">Creado el <em>' . explodear(' ',$row['time'], 0) . '</em>, &uacute;ltima edici&oacute;n hace <em>' . duracion(time() - strtotime($row['time_last'])) . '</em>.</span><span><a href="/doc/"><b>Ver documentos</b></a></span>';  }
		}

		$txt_title = $row['title'];
	}


} else { //docs/

	$txt .= '<h1><img src="/img/doc.gif" alt="Documento" /> Documentos de POL</h1>

<p>Los Documentos de POL es el sistema principal para los textos de POL. Esto permite crear un documento normal u oficial para cualquier fin. Los documentos pueden confeccionarse de forma colaborativa y con diversos niveles de acceso.</p>

<table border="0" cellspacing="0" cellpadding="0" class="pol_table">
<tr>
<th>Nivel&darr;</th>
<th>T&iacute;tulo</th>
<th colspan="2">&Uacute;ltima edici&oacute;n</th>
<th>Fecha</th>
<th></th>
</tr>';

	$result = mysql_query("SELECT 
title, url, time, nivel, estado, time_last, 
(SELECT nick FROM pol_users WHERE ID = pol_docs.user_ID LIMIT 1) AS nick_autor
FROM pol_docs
WHERE estado = 'ok'
ORDER BY nivel DESC, title ASC", $link);
	while($row = mysql_fetch_array($result)){
		if ($pol['nivel'] >= $row['nivel']) { 
			$editar = '<form><input type="button" value="Editar" onclick="window.location.href=\'/doc/' . $row['url'] . '/editar/\'" style="margin-bottom:-16px;"></form>';
		}
		$txt .= '<tr><td align="right"><b>' . $row['nivel'] . '</b></td><td><b><a href="/doc/' . $row['url'] . '/">' . $row['title'] . '</a></b></td><td>' . crear_link($row['nick_autor']) . '</td><td align="right">' . str_replace(' ', '&nbsp;', duracion(time() - strtotime($row['time_last']))) . '</td><td>' . explodear(' ', $row['time'], 0) . '</td><td>' . $editar . '</td></tr>' . "\n";
		$editar = '';
	}
	$txt .= '</table>';

	$txt .= '<p>' . boton('Crear Documento', '/form/crear-documento/') . '</p>';

	$txt_title = 'Documentos';
}



//THEME

include('theme.php');
?>