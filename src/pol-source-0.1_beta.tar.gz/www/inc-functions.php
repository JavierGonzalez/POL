<?php

function duracion($t) {
	if ($t > 31536000) { $d = round($t / 31536000) . ' a&ntilde;os'; }
	elseif ($t > 5356800) { $d = round($t / 2626560) . ' meses'; }
	elseif ($t > 129600) { $d = round($t / 86400) . ' d&iacute;as'; }
	elseif ($t > 86400) { $d = '1 d&iacute;a'; }
	elseif ($t > 7200) { $d = round($t / 3600) . ' horas'; }
	elseif ($t > 3600) { $d = '1 hora'; }
	elseif ($t > 60) { $d = round($t / 60) . ' min'; }
	else { $d = $t . ' seg'; }
	return $d;
}

function crear_link($a, $tipo='nick') {
	switch ($tipo) {
		case 'nick': if ($a) { return '<a href="/perfil/' . strtolower($a) . '/">' . $a . '</a>'; } else { return '&dagger;';  } break;
		case 'partido': if ($a) { return '<a href="/partidos/' . strtolower($a) . '/">' . $a . '</a>'; } else { return 'Ninguno'; } break;
		case 'documento': return '<a href="/doc/' . $a . '/">/doc/' . $a . '/</a>'; break;
	}
}

function explodear($patron, $string, $num) { $expl = explode($patron, $string); return $expl[$num]; }

function menu_in($url_es) {
	$url_esta = $_SERVER['REQUEST_URI'];
	if (((strpos($url_esta, $url_es) !== false) AND ($url_es != '/')) OR ($url_es == $url_esta)) { echo ' <span style="color:grey;">&#9668;</span>'; }
}

function evento_log($accion, $dato='', $user_ID2='', $user_ID='') {
	global $pol, $link; 
	$user_ID = $pol['user_ID'];
	mysql_query("INSERT INTO pol_log 
(time, user_ID, user_ID2, accion, dato) 
VALUES ('" . date('Y-m-d H:i:s') . "', '" . $user_ID . "', '" . $user_ID2 . "', '" . $accion . "', '" . $dato . "')", $link);
}


function cargo_add($cargo_ID, $user_ID) {
	global $link; 
	$result = mysql_query("SELECT nivel FROM pol_estudios WHERE ID = '" . $cargo_ID . "' LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){
		mysql_query("UPDATE pol_estudios_users SET cargo = '1' WHERE ID_estudio = '" . $cargo_ID . "' AND user_ID = '" . $user_ID . "' AND estado = 'ok' LIMIT 1", $link);
		mysql_query("UPDATE pol_users SET nivel = '" . $row['nivel'] . "' WHERE ID = '" . $user_ID . "' AND nivel < '" . $row['nivel'] . "' LIMIT 1", $link);
		evento_log(11, $cargo_ID, $user_ID);
	}
}

function cargo_del($cargo_ID, $user_ID) {
	global $link; 
	$result = mysql_query("SELECT nivel FROM pol_estudios WHERE ID = '" . $cargo_ID . "' LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){
		mysql_query("UPDATE pol_estudios_users SET cargo = '0' WHERE ID_estudio = '" . $cargo_ID . "' AND user_ID = '" . $user_ID . "' AND estado = 'ok' LIMIT 1", $link);
		evento_log(12, $cargo_ID, $user_ID);
		$result = mysql_query("SELECT ID_estudio, 
(SELECT nivel FROM pol_estudios WHERE ID = pol_estudios_users.ID_estudio LIMIT 1) AS nivel
FROM pol_estudios_users 
WHERE user_ID = '" . $user_ID . "' AND cargo = '1' 
ORDER BY nivel DESC
LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $user_nivel_max = $row['nivel']; }
		if (!$user_nivel_max) { $user_nivel_max = 1; }
		if ($user_ID != 1) { mysql_query("UPDATE pol_users SET nivel = '" . $user_nivel_max . "' WHERE ID = '" . $user_ID . "' LIMIT 1", $link); }
	}
}

function boton($value, $url, $confirm=false, $m='', $pols=false) {
	if ($pols) {
		global $pol;
		if ($pol['pols'] >= $pols) { $disabled = ''; } else { $disabled = ' disabled="disabled"'; }
		if ($url) {
			return '<span class="amarillo"><input type="button" value="' . $value . '"' . $disabled . ' onClick="window.location.href=\'' . $url . '\';" /> &nbsp; ' . pols($pols) . ' POLs</span>';
		} else {
			return '<span class="amarillo"><input type="submit" value="' . $value . '"' . $disabled . ' /> &nbsp; ' . pols($pols) . ' POLs</span>';
		}
	} elseif (($confirm) AND ($confirm != 'm')) { return '<input type="button" value="' . $value . '" onClick="if (!confirm(\'' . $confirm . '\')) { return false; } else { window.location.href=\'' . $url . '\'; }" />';
	} else {
		if ($confirm == 'm') { $style = ' style="margin-bottom:-16px;"'; }
		return '<input type="button" value="' . $value . '" onClick="window.location.href=\'' . $url . '\';"' . $style . ' />'; 
	}
}

function form_select_nivel($nivel_select='') {
	global $pol, $link;
	$f .= '<select name="nivel"><option value="1">(1) Ciudadano</option>';
	if ($pol['nivel'] > 1) {
		$result = mysql_query("
SELECT nombre, nivel 
FROM pol_estudios 
WHERE asigna != '-1' AND nivel <= '" . $pol['nivel'] . "' 
ORDER BY nivel ASC", $link);
		while($row = mysql_fetch_array($result)){
			if ($nivel_select == $row['nivel']) { $selected = ' selected="selected"'; } else { $selected = ''; }
			$f .= '<option value="' . $row['nivel'] . '"' . $selected . '>(' . $row['nivel'] . ') ' . $row['nombre'] . '</option>' . "\n";
		}
	}
	if (($pol['nick'] == 'GONZO') AND ($nivel_select == 120)) { $f .= '<option value="120" selected="selected">(120) Dev</option>'; }
	$f .= '</select>';
	return $f;
}

function evento_chat($msg, $user_ID='0', $sql_chat='plaza') {
	global $pol, $link;
	mysql_query("INSERT INTO pol_chat_" . $sql_chat . " (user, time, msg, type, user_ID) VALUES ('" . $pol['nick'] . "', '" . date('Y-m-d H:i:s') . "', '" . $msg . "', '#', '" . $user_ID . "')", $link);
}

function cargos() {
	global $pol, $link; 
	$result = mysql_query("SELECT ID_estudio FROM pol_estudios_users WHERE estado = 'ok' AND cargo = '1' AND user_ID = '" . $pol['user_ID'] . "'", $link);
	while($row = mysql_fetch_array($result)) { $cargos[$row['ID_estudio']] = true; }
	return $cargos;
}

function paginacion($type, $url, $ID, $num_ahora=null, $num_total=null, $num='10') {
	global $link, $p_limit, $p_paginas;

	if (!$num_total) {
		switch ($type) {
			case 'subforo': 
				$result = mysql_fetch_row(mysql_query("SELECT COUNT(ID) FROM pol_foros_hilos WHERE ID = '" . $ID . "'", $link));
				$num_total = $result[0];
				break;
			case 'eventos': 
				$result = mysql_fetch_row(mysql_query("SELECT COUNT(ID) FROM pol_log", $link));
				$num_total = $result[0];
				break;
		}
	}

	if ($num_total == 1) {
		$num_paginas = 1;
	} else {
		$num_paginas = ceil(($num_total - 1) / $num);
	}

	if (($type == 'censo') OR ($type == 'eventos')) {
		if (!$num_ahora) { $num_ahora = 1; }
		for ($i=1;$i <= $num_paginas;$i++) {
			if ($i == 1) { $el_url = $url;
			} else { $el_url = $url . $i . '/'; }
			if ($i == $num_ahora) {
				$html .= '<span class="amarillo">&nbsp;<b><a href="' . $el_url . '">' . $i . '</a></b>&nbsp;</span> ';
			} else {
				$html .= '<a href="' . $el_url . '">' . $i . '</a> ';
			}
		}
		$p_limit = (($num_ahora - 1) * $num) . ', ' . $num;




	} else {
		if (!$num_ahora) { $num_ahora = $num_paginas; }

		for ($i=1;$i <= $num_paginas;$i++) {

			if ($i == $num_paginas) { $el_url = $url; } 
			else { $el_url = $url . $i . '/'; }

			if ($i == $num_ahora) {
				$html .= '<span class="amarillo">&nbsp;<b><a href="' . $el_url . '">' . $i . '</a></b>&nbsp;</span> ';
			} else {
				$html .= '<a href="' . $el_url . '">' . $i . '</a> ';
			}

		}
		$p_limit = (($num_ahora - 1) * $num) . ', ' . $num;


	}
	

	$p_paginas = '<span style="font-size:20px;">' . $html . '</span>';
}

function chart_data($values) {
	$maxValue = max($values);
	$simpleEncoding = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	$chartData = "s:";
	for ($i = 0; $i < count($values); $i++) {
		$currentValue = $values[$i];
		if ($currentValue == 0) {
			$chartData.=substr($simpleEncoding,61*0,1);
		} elseif ($currentValue > -1) { $chartData.=substr($simpleEncoding,61*($currentValue/$maxValue),1); }
		else { $chartData.='_'; }
	}
	return $chartData;
}


function enviar_email($user_ID, $asunto, $mensaje, $email='') {
	$cabeceras = "From: POL <pol@teoriza.com> \nReturn-Path: POL <pol@teoriza.com>\n X-Sender: POL <pol@teoriza.com>\n From: POL <pol@teoriza.com>\n MIME-Version: 1.0\nContent-type: text/html\n";

	if (($user_ID) AND ($email == '')) {
		global $link;
		$result = mysql_unbuffered_query("SELECT email FROM pol_users WHERE ID = '" . $user_ID . "' LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $email = $row['email']; }
	}
	mail($email, $asunto, $mensaje, $cabeceras);
}

function pols_transferir($pols, $emisor_ID, $receptor_ID, $concepto) {
	global $link;
	$return = false;
	if ((ctype_digit($pols)) AND ($pols != 0) AND ($concepto)) {
		$concepto = ucfirst(strip_tags($concepto));

		//quitar
		if (substr($emisor_ID, 0, 1) != '-') {
			mysql_query("UPDATE pol_users SET pols = pols - " . $pols . " WHERE ID = '" . $emisor_ID . "' LIMIT 1", $link);
		} else {
			mysql_query("UPDATE pol_cuentas SET pols = pols - " . $pols . " WHERE ID = '" . substr($emisor_ID, 1) . "' LIMIT 1", $link);
		}

		//ingresar
		if (substr($receptor_ID, 0, 1) != '-') {
			mysql_query("UPDATE pol_users SET pols = pols + " . $pols . " WHERE ID = '" . $receptor_ID . "' LIMIT 1", $link);
		} else {
			mysql_query("UPDATE pol_cuentas SET pols = pols + " . $pols . " WHERE ID = '" . substr($receptor_ID, 1) . "' LIMIT 1", $link);
		}

		mysql_query("INSERT INTO pol_transacciones (pols, emisor_ID, receptor_ID, concepto, time) VALUES ('" . $pols . "', '" . $emisor_ID . "', '" . $receptor_ID . "', '" . $concepto . "', '" . date('Y-m-d H:i:s') . "')", $link);
		$return = true;
	}
	return $return;
}

function pols($pols) {
	$pols = number_format($pols, 0, ',', '.');
	if (substr($pols, 0, 1) == '-') { $pols = '<span class="pn">' . $pols . '</span>'; } 
	else { $pols = '<span class="pp">' . $pols . '</span>'; }
	return $pols;
}


function eliminar_ciudadano($ID) {
	global $link;
	$user_ID = false;

	$margen_15dias = date('Y-m-d H:i:s', time() - 1296000); //15dias
	$result3 = mysql_query("SELECT pols, nick, ID FROM pol_users WHERE fecha_last < '" . $margen_15dias . "' AND ID = '" . $ID . "' LIMIT 1", $link);
	while($row3 = mysql_fetch_array($result3)) { $user_ID = $row3['ID']; $pols = $row3['pols']; $nick = $row3['nick']; }

	if ($user_ID) {
		if ($pols > 0) { pols_transferir($pols, $user_ID, '-1', 'Defuncion de <em>' . $nick . '</em> &dagger;'); }
		mysql_query("DELETE FROM pol_users WHERE ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_transacciones WHERE emisor_ID = '" . $user_ID . "' OR receptor_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_ref_votos WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_referencias WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_partidos_listas WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_partidos WHERE ID_presidente = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_mercado WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_mensajes WHERE recibe_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_log WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_estudios_users WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_cuentas WHERE user_ID = '" . $user_ID . "'", $link);
		mysql_query("DELETE FROM pol_ban WHERE user_ID = '" . $user_ID . "'", $link);
	}

}

function editor_enriquecido($name, $txt='') {

	$GLOBALS['txt_header'] .= '
<script type="text/javascript" src="/img/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
tinyMCE.init({
mode : "textareas",
theme : "advanced",
language : "es",
 
theme_advanced_buttons1 : "bold,italic,strikethrough,|,forecolor,fontsizeselect,|,link,unlink,|,bullist,numlist,blockquote,hr,|,removeformat,cleanup,|,undo,redo",
theme_advanced_buttons2 : "",
theme_advanced_buttons3 : "",

theme_advanced_toolbar_location : "top",
theme_advanced_toolbar_align : "left",
theme_advanced_statusbar_location : "bottom",
theme_advanced_resizing : true
});
</script>';

	return '<textarea name="' . $name . '" style="width:750px;height:350px;">' . $txt . '</textarea>';
}
?>