<?php
include('inc-login.php');
if ($pol['nick'] == 'GONZO') {



$txt .= '

<table border="0" cellspacing="4">
<tr>
<th>ID</th>
<th>nick</th>
<th>IP</th>
<th></th>
</tr>';

$result = mysql_query("SELECT ID, nick, email,
(SELECT IP FROM teoriza_users WHERE ID = pol_users.ID LIMIT 1) AS IP
FROM pol_users
ORDER BY IP DESC
LIMIT 400", $link);
while($row = mysql_fetch_array($result)) {
	if ($IP_last == $row['IP']) { $coincide = '!!!'; } else { $coincide = ''; }
	$txt .= '<tr><td align="right">' . $row['ID'] . '</td><td><b>' . $row['nick'] . '</b></td><td>' . long2ip($row['IP']) . '</td><td>' . $coincide . '</td></tr>';
	$IP_last = $row['IP'];
}
$txt .= '</table>';


}


//THEME
$txt_title = 'TEST';
include('theme.php');
?>