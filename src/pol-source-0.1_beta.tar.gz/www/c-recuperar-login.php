<?php 
include('inc-login.php');

$txt .= '<h1>Recuperar Contrase&ntilde;a</h1>';

$txt .= '<p>Si has perdido tu contrase&ntilde;a debes escribirnos un email a <em>pol@teoriza.com</em>, desde tu email de registro y gestionaremos tu recuperaci&oacute;n.</p><p>Proximamente esta funcionalidad ser&aacute; autom&aacute;tica. Gracias.</p>';


//THEME
$txt_title = 'Recuperar contrase&ntilde;a';
include('theme.php');
?>