<?php 
include('inc-login.php');


$_GET['a'] = trim($_GET['a']);


$result = mysql_query("SELECT *, 
(SELECT siglas FROM pol_partidos WHERE ID = pol_users.partido_afiliado LIMIT 1) AS partido
FROM pol_users 
WHERE nick = '" . $_GET['a'] . "'
LIMIT 1", $link);
while($row = mysql_fetch_array($result)){

	$user_ID = $row['ID'];
	if ($user_ID) { //nick existe
		$nick = $row['nick'];
		$txt .= '<h1><span class="amarillo"><img src="/img/perfil.gif" alt="Perfil" border="0" /> ' . $nick . '</span> &nbsp; <span style="color:grey;">(' . ucfirst($row['estado']) . ')</span></h1><br /><div id="info">';

		$cargos_num = 0;
		$estudios_num = 0;
		$result = mysql_query("SELECT ID_estudio, cargo, 
(SELECT nombre FROM pol_estudios WHERE ID = pol_estudios_users.ID_estudio LIMIT 1) AS nombre, 
(SELECT nivel FROM pol_estudios WHERE ID = pol_estudios_users.ID_estudio LIMIT 1) AS nivel
FROM pol_estudios_users
WHERE user_ID = '" . $user_ID . "' AND estado = 'ok'
ORDER BY nivel DESC, time ASC", $link);
		while($row2 = mysql_fetch_array($result)) {
			if ($row2['cargo'] == 1) { $cargos_num++; $cargos .= '<b>' . $row2['nombre'] . '</b><br />' . "\n"; }
			$estudios_num++;
			$estudios .= '<img src="/img/estudiado.gif" alt="Estudiado" border="0" /> <b>' . $row2['nombre'] . '</b><br />' . "\n";
		}


		if ($user_ID == $pol['user_ID']) { //es USER

			$result2 = mysql_query("SELECT valor FROM pol_config WHERE dato = 'pols_afiliacion' LIMIT 1", $link);
			while($row2 = mysql_fetch_array($result2)){ if ($row2['pols'] >= $pols) { $pols_afiliacion = $row2['valor']; } }
			
			$txt .= '
<div class="amarillo">
<p>Tienes <b>' . pols($row['pols']) . ' POLs</b></p>
<p>Afiliado a: <b>' . crear_link($row['partido'], 'partido') . '</b> ' . boton('Afiliarse', '/form/afiliarse/') . '</p>
<p>Referencia: <input type="text" size="35" value="http://pol.teoriza.com/ref/' . strtolower($nick) . '/" readonly="readonly" /><br />
(Ganar&aacute;s <b>' . pols($pols_afiliacion) . ' POLs</b> por cada nuevo Ciudadano autentico que se registre por este enlace)</p>
<p>Clave API: <input class="api_box" type="text" size="12" value="' . $row['api_pass'] . '" readonly="readonly" /> ' . boton('Generar clave', '/accion.php?a=api&b=gen_pass', '&iquest;Seguro que deseas CAMBIAR tu clave API?\n\nLa antigua no funcionar&aacute;.') . '<br />(Esta clave equivale a tu contrase&ntilde;a, mantenla en secreto. M&aacute;s info: <a href="/api.php">API de POL</a>)</p>
<p>' . boton('Cambiar contrase&ntilde;a', 'http://www.teoriza.com/registrar/login.php?a=panel') . '</p>
</div>';

		} else {
			$txt .= '<p>' . boton('Enviar mensaje', '/msg/' . strtolower($nick) . '/') . '<br />' . boton('Transferir POLs', '/pols/transferir/' . strtolower($nick) . '/') . '</p>';
		}




		if ($row['ref_num'] != 0) {
			$result = mysql_query("SELECT nick FROM pol_users WHERE ref = '" . $row['ID'] . "' ORDER BY fecha_registro DESC", $link);
			while($row2 = mysql_fetch_array($result)) {
				$refs .= crear_link($row2['nick']) . '<br />' . "\n";
			}
		}






		$txt .= '
<p>Tiempo online: <b>' . duracion($row['online']) . '</b></p>
<p>Elecciones: <b>' . $row['num_elec'] . '</b></p>
<p>Referencias: <b>' . $row['ref_num'] . '</b><br /><b>' . $refs . '</b></p>
<p>Cargos: <b>' . $cargos_num . '</b><br />' . $cargos . '</p>
<p>Estudios: <b>' . $estudios_num . '</b> ' . boton('Estudiar', '/estudios/') . '<br />' . $estudios . '</p>
<p>Nacido el: <b>' .  explodear(' ', $row['fecha_registro'], 0) . '</b> (hace ' . duracion(time() - strtotime($row['fecha_registro'])) . ')<br />
Ultimo acceso: <b>' . duracion(time() - strtotime($row['fecha_last'])) . '</b></p>
</div>';

	} else { header("HTTP/1.0 404 Not Found"); exit; }
}


$txt_header .= '<style type="text/css">
#info b { color:green; }
.api_box { border: 1px solid grey; text-align:center; background:#FFFFDD; color:#FFFFDD; }
.api_box:hover { color:green; }
</style>';

//THEME
$txt_title = 'Ciudadano ' . $nick . ', perfil de usuario';
include('theme.php');
?>