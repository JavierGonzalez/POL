<?php 
include('inc-login.php');

function gen_grafico($datos, $fecha, $cero=false) {
	$maxValue = max($datos);
	if ($cero) { $datos = strtr(chart_data($datos), "A", "_"); } else { $datos = chart_data($datos); }
	$g .= 'http://chart.apis.google.com/chart?cht=lc';
	$g .= '&chs=700x120';
	$g .= '&chxt=x,y';
	$g .= '&chxl=0:' . $fecha . '|1:|____|' . $maxValue;
	$g .= '&chd=' . $datos;
	$g .= '&chf=bg,s,FFFFDD,0&chco=0066FF';
	$g .= '&chm=B,FFFFFF,0,0,0';
	return $g;
}

switch ($_GET['a']) {

case 'estadisticas':
	$txt_title = 'Estad&iacute;sticas, gr&aacute;ficos hist&oacute;ricos ';

	$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_stats", $link);
	while($row = mysql_fetch_array($result)) { $num_total = $row['num']; }

	paginacion('hilo', '/info/estadisticas/', null, $_GET['b'], $num_total, 50);

	$i = 0;
	$result = mysql_query("SELECT * FROM pol_stats ORDER BY time ASC LIMIT " . $p_limit, $link);
	while($row = mysql_fetch_array($result)) {

		$datos['ciudadanos'][$i] = $row['ciudadanos'];
		$datos['nuevos'][$i] = $row['nuevos'];
		$datos['hilos_msg'][$i] = $row['hilos_msg'];
		$datos['partidos'][$i] = $row['partidos'];
		$datos['empresas'][$i] = $row['empresas'];

		$datos['pols'][$i] = $row['pols'];
		$datos['pols_cuentas'][$i] = $row['pols_cuentas'];
		$datos['pol_gobierno'][$i] = $row['pol_gobierno'];
		$datos['transacciones'][$i] = $row['transacciones'];
		$datos['pols_total'][$i] = $row['pols'] + $row['pols_cuentas'];
		$datos['frase'][$i] = $row['frase'];

		$fecha = date('j', strtotime($row['time']));
		$datos['fecha'] .= '|' . $fecha;
		$i++;
	}

/*
pol_stats (ID, time, ciudadanos, nuevos, pols, pols_cuentas, transacciones, hilos_msg, pol_gobierno, partidos)
*/

	$txt .= '<h1>Estad&iacute;sticas de POL <span style="font-size:12px;">(&Uacute;ltimos ' . $i . ' d&iacute;as)</span></h1>

<p>' . $p_paginas . '</p>

<h2 style="margin-top:35px;">Censo:</h2>
<p class="amarillo"><b>Ciudadanos</b> (<a href="/info/censo/">Ver censo</a>)<br />
<img src="' . gen_grafico($datos['ciudadanos'], $datos['fecha']) . '" alt="Ciudadanos censo" border="0" />
</p>

<p class="amarillo"><b>Ciudadanos nuevos</b>  (<a href="/info/censo/nuevos/">Ver nuevos</a>)<br />
<img src="' . gen_grafico($datos['nuevos'], $datos['fecha']) . '" alt="Ciudadanos nuevos" border="0" />
</p>

<h2 style="margin-top:35px;">Actividad:</h2>
<p class="amarillo"><b>Foro, nuevos mensajes</b> (<a href="/foro/">Ver foro</a>)<br />
<img src="' . gen_grafico($datos['hilos_msg'], $datos['fecha'], true) . '" alt="Mensajes en el Foro" border="0" />
</p>

<p class="amarillo"><b>Partidos pol&iacute;ticos</b> (<a href="/partidos/">Ver partidos</a>)<br />
<img src="' . gen_grafico($datos['partidos'], $datos['fecha']) . '" alt="Partidos" border="0" />
</p>

<p class="amarillo"><b>Empresas</b> (<a href="/empresas/">Ver empresas</a>)<br />
<img src="' . gen_grafico($datos['empresas'], $datos['fecha'], true) . '" alt="Empresas" border="0" />
</p>

<p class="amarillo"><b>Transacciones</b> (<a href="/pols/">Ver transferencias</a>)<br />
<img src="' . gen_grafico($datos['transacciones'], $datos['fecha'], true) . '" alt="Transacciones" border="0" />
</p>

<h2 style="margin-top:35px;">Econom&iacute;a:</h2>
<p class="amarillo"><b>POLs en total</b> (<a href="/doc/economia/#circulo_dinero">Ver circulo del dinero</a>)</b><br />
<img src="' . gen_grafico($datos['pols_total'], $datos['fecha'], true) . '" alt="POLs en total" border="0" />
</p>

<p class="amarillo"><b>POLs de Ciudadanos</b> (<a href="/info/censo/riqueza/">Ver los m&aacute;s ricos</a>)<br />
<img src="' . gen_grafico($datos['pols'], $datos['fecha'], true) . '" alt="POLs de ciudadanos" border="0" />
</p>

<p class="amarillo"><b>POLs en Cuentas</b> (<a href="/pols/cuentas/">Ver cuentas</a>)<br />
<img src="' . gen_grafico($datos['pols_cuentas'], $datos['fecha'], true) . '" alt="POLs en cuentas" border="0" />
</p>

<p class="amarillo"><b>POLs cuenta: Gobierno de POL</b> (<a href="/pols/cuentas/1/">Ver cuenta Gobierno</a>)<br />
<img src="' . gen_grafico($datos['pol_gobierno'], $datos['fecha'], true) . '" alt="POLs Cuenta Gobierno" border="0" />
</p>

<p class="amarillo"><b>Subasta: <em>la frase</em></b> (Referencia econ&oacute;mica)<br />
<img src="' . gen_grafico($datos['frase'], $datos['fecha'], true) . '" alt="Subasta: la frase" border="0" />
</p>

<p>' . $p_paginas . '</p>';





	break;

case 'economia':
	$txt .= '<h1>Econom&iacute;a de POL</h1>';

	$result = mysql_query("SELECT SUM(pols) AS num FROM pol_users", $link);
	while($row = mysql_fetch_array($result)) {
		$pols_ciudadanos = $row['num'];
		$txt .= '<p>Ciudadanos: <b>' . pols($row['num']) . '</b> POLs</p>';
	}

	$result = mysql_query("SELECT SUM(pols) AS num FROM pol_cuentas", $link);
	while($row = mysql_fetch_array($result)) {
		$pols_cuentas = $row['num'];
		$txt .= '<p>En cuentas: <b>' . pols($row['num']) . '</b> POLs</p>';
	}

	$txt .= '<p>Total: <b>' . pols($pols_ciudadanos + $pols_cuentas) . '</b> POLs</p>';

	break;


case 'elecciones-generales':

	$txt .= '<h1>Elecciones Generales</h1>';

	if ($pol['config']['elecciones_estado'] == 'normal') { $estado = '[1] Periodo normal'; }
	elseif ($pol['config']['elecciones_estado'] == 'elecciones') { $estado = '[2] Periodo de Elecciones Generales'; }
	$txt .= '<ul id="info"><li>Estado actual: <b>' . $estado . '</b> (<a href="/doc/elecciones-generales/">info</a>)</li>';



	if ($pol['config']['elecciones_estado'] == 'normal') {
		
		$txt .= '<li>Pr&oacute;ximas: <b>' . explodear(' ', $pol['config']['elecciones_inicio'], 0) . ' 22:00</b> (faltan ' . duracion(strtotime($pol['config']['elecciones_inicio']) - time()) . ')</li>';
		$txt .= '<li>Duraci&oacute;n de las votaciones: <b>' . duracion($pol['config']['elecciones_duracion']) . '</b></li>';
		$txt .= '<li>Elecciones cada: <b>' . duracion($pol['config']['elecciones_frecuencia'] + $pol['config']['elecciones_duracion']) . '</b></li>';
		$txt .= '<li>Esca&ntilde;os: <b>' . $pol['config']['num_esca�os'] . '</b></li>';
			
		$txt .= '</ul>

<table><tr><td valign="top">

<h2>Parlamento (esca&ntilde;os)</h2>

<table border="0" class="pol_table">
<tr>
<th>Cargo</th>
<th>Nombre</th>
<th>Partido</th>
</tr>';

	$esca�os = 0;
	$result = mysql_query("SELECT ID_partido, 
(SELECT siglas FROM pol_partidos WHERE ID = pol_diputados.ID_partido LIMIT 1) AS partido,
(SELECT nick FROM pol_users WHERE ID = pol_diputados.user_ID LIMIT 1) AS nick
FROM pol_diputados ORDER BY ID_partido ASC, ID ASC", $link);
	while($row = mysql_fetch_array($result)){
		$esca�os++;
		$array_esca�os[$row['ID_partido']]++;
		$array_esca�os_nom[$row['ID_partido']] = $row['partido'];
		if ($esca�os == 1) { $cargo = 'Presidente'; } else { $cargo = 'Diputado'; }
		$txt .= '<tr><td><b>' . $cargo . '</b></td><td><b>' . crear_link($row['nick']) . '</b></td><td>' . crear_link($row['partido'], 'partido') . '</td></tr>';
	}

	$result = mysql_query("SELECT ID_partido FROM pol_elecciones", $link);
	while($row = mysql_fetch_array($result)){ $votos[$row['ID_partido']]++; $votos_total++; }
	arsort($votos); reset($votos);
	foreach($votos as $ID_partido => $votos) {
		$result = mysql_query("SELECT siglas FROM pol_partidos WHERE ID = '" . $ID_partido . "' LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $s_partido = $row['siglas']; }

		if ($ID_partido == 0) { $nombre_partido = 'En Blanco'; } else { $nombre_partido = crear_link($s_partido, 'partido'); }

		$txt_escrutinio .= '<tr><td><b>' . $nombre_partido . '</b></td><td><b>' . $votos . '</b></td><td>' . round(($votos * 100) / $votos_total) . '%</td><td><b>' . $array_esca�os[$ID_partido] . '</b></td></tr>';


		if ($chart_dato) { $chart_dato .= ','; } $chart_dato .= $votos;
		if ($ID_partido != 0) {
			if ($chart_nom) { $chart_nom .= '|'; } $chart_nom .= $s_partido;
		}

		if ($ID_partido != 0) {
			if ($chart2_dato) { $chart2_dato .= ','; } $chart2_dato .= $array_esca�os[$ID_partido];
			if ($chart2_nom) { $chart2_nom .= '|'; } $chart2_nom .= $s_partido;
		}

	}
	if (!$votos[0]) { $votos_blanco = 0; } else { $votos_blanco = $votos[0]; }
	
	$chart_dato .= ',' . $votos_blanco;
	$chart_nom .= '|En Blanco';


	//http://chart.apis.google.com/chart?cht=p&chd=t:6,4,2&chs=440x200&chl=|No|Si
	$txt .= '</table>

</td><td>
<img src="http://chart.apis.google.com/chart?cht=p&chd=t:' . $pol['config']['num_esca�os'] . ',' . $chart2_dato . '&chs=400x280&chl=|' . $chart2_nom . '&chco=FFFFFF,FF8000" alt="Gobierno Esca&ntilde;os" />
</td></tr>

<tr><td valign="top">


<br /><h2>Escrutinio (votos)</h2>

<table border="0" class="pol_table">
<tr>
<th>Partido</th>
<th>Votos</th>
<th></th>
<th>Esca&ntilde;os</th>
</tr>' . $txt_escrutinio . '</table>


</td><td>
<img src="http://chart.apis.google.com/chart?cht=p&chd=t:' . $chart_dato . '&chs=320x200&chl=' . $chart_nom . '" alt="Escrutinio Votos" />
</td></tr></table>';


	} elseif ($pol['config']['elecciones_estado'] == 'elecciones') {

		$fecha_24_antes = date('Y-m-d H:i:00', strtotime($pol['config']['elecciones_inicio']) - $pol['config']['elecciones_antiguedad']);
		
		$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_users WHERE estado = 'ciudadano' AND fecha_registro < '" . $fecha_24_antes . "'", $link);
		while($row = mysql_fetch_array($result)) { $num_votantes = $row['num']; }

		$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_elecciones", $link);
		while($row = mysql_fetch_array($result)) { $num_votos = $row['num']; }

		$txt .= '<li>Fecha de Inicio: <b>' . explodear(' ', $pol['config']['elecciones_inicio'], 0) . '</b> (hace ' . duracion(time() - strtotime($pol['config']['elecciones_inicio'])) . ')</li>';
		$txt .= '<li>Finalizaci&oacute;n: <b>en ' . duracion((strtotime($pol['config']['elecciones_inicio']) + $pol['config']['elecciones_duracion']) - time()) . '</b></li>';

		$txt .= '<li>Votantes: <b>' . $num_votantes . '</b> (Todo Ciudadano registrado antes de: <em>' . explodear(' ', $fecha_24_antes, 0) . '</em>)</li>';
		$txt .= '<li>Votos: <b>' . $num_votos . '</b></li>';
		$txt .= '<li>Participaci&oacute;n actual: <b>' . round(($num_votos * 100) / $num_votantes) . '%</b></li>';

		$result = mysql_query("SELECT ID FROM pol_elecciones WHERE user_ID = '" . $pol['user_ID'] . "'", $link);
		while($row = mysql_fetch_array($result)) { $has_votado = $row['ID']; }

		if (!$has_votado) { $txt .= '<li><span><form><input type="button" value="Ir a votar" onClick="window.location.href=\'/form/elecciones-generales/\';" /> A&uacute;n no has votado! </form></span></li>'; }
		else { $txt .= '<li>Tu voto ha sido ejercido correctamente.</li>'; }
		$txt .= '</ul>';

	}

	$txt .= '<p><a href="/partidos/"><b>Ver Partidos</b></a> &nbsp; <a href="/cargos/"><b>Ver Cargos</b></a></p>';

	$txt_header .= '<style type="text/css">#info li { margin-top:5px; } #info li b { color:green; }</style>';
	$txt_title = 'Elecciones Generales - Esca&ntilde;os - Escrutinio';
	break;


case 'censo':


	$result = mysql_fetch_row(mysql_query("SELECT COUNT(ID) FROM pol_users", $link));
	$censo_total = $result[0];

	$time_margen = date('Y-m-d H:i:00', time() - 86400); //1 dia
	$result = mysql_fetch_row(mysql_query("SELECT COUNT(ID) FROM pol_users WHERE fecha_last > '" . $time_margen . "'", $link));
	$censo_1dia = $result[0];

	$time_margen = date('Y-m-d H:i:00', time() - 259200); //3 dias
	$result = mysql_fetch_row(mysql_query("SELECT COUNT(ID) FROM pol_users WHERE fecha_last > '" . $time_margen . "'", $link));
	$censo_2dias = $result[0];

	$time_margen = date('Y-m-d H:i:00', time() - 1296000); //15 dias
	$result = mysql_fetch_row(mysql_query("SELECT COUNT(ID) FROM pol_users WHERE fecha_last > '" . $time_margen . "'", $link));
	$censo_15dias = $result[0];

	if (($_GET['b']) AND (!is_numeric($_GET['b']))) { 
		$pagina = $_GET['c'];
		$pagina_url = '/info/censo/' . $_GET['b'] . '/';
	} else { 
		$pagina = $_GET['b']; 
		$pagina_url = '/info/censo/';
	}

	paginacion('censo', $pagina_url, null, $pagina, $censo_total, 25);

if ($_GET['b'] == 'nuevos') {
	$old = 'antiguedad';
} else {
	$old = 'nuevos';
}

	$txt .= '<h1>Censo de Ciudadanos</h1>

<p>' . $p_paginas . ' &nbsp; Total: <b>' . $censo_total . '</b>  (1 dia: <b>' . $censo_1dia . '</b>, 3 dias: <b>' . $censo_2dias . '</b>, 15 dias: <b>' . $censo_15dias . '</b>) &nbsp; <a href="/info/censo/riqueza/">Riqueza</a> &nbsp; <a href="/info/estadisticas/">Estad&iacute;sticas</a></p>

<table border="0" cellspacing="0" cellpadding="2" class="pol_table">
<tr>
<th><a href="/info/censo/nivel/">Nivel</a></th>
<th>Nombre</th>
<th>Afiliaci&oacute;n</th>
<th><a href="/info/censo/online/">Online</a></th>
<th><a href="/info/censo/' . $old . '/">Antiguedad</a></th>
<th><a href="/info/censo/elec/"><acronym title="Elecciones en las que ha participado.">Elec</acronym></a></th>
<th><a href="/info/censo/refs/"><acronym title="Referencias">Refs</acronym></a></th>
<th colspan="2"><a href="/info/censo/">&Uacute;ltimo&nbsp;acceso&darr;</a></th>
</tr>';

	switch ($_GET['b']) {
		case 'nivel': $order_by = 'WHERE ID != \'1\' ORDER BY nivel DESC'; break;
		case 'nuevos': $order_by = 'ORDER BY fecha_registro DESC'; break;
		case 'antiguedad': $order_by = 'ORDER BY fecha_registro ASC'; break;
		case 'elec': $order_by = 'ORDER BY num_elec DESC'; break;
		case 'online': $order_by = 'ORDER BY online DESC'; break;
		case 'riqueza': $order_by = 'ORDER BY pols DESC'; break;
		case 'refs': $order_by = 'ORDER BY ref_num DESC'; break;
		default: $order_by = 'ORDER BY fecha_last DESC';
	}


	$result = mysql_query("SELECT nick, fecha_registro, fecha_last, nivel, num_elec, online, ref_num, ref,
(SELECT siglas FROM pol_partidos WHERE pol_users.partido_afiliado != '0' AND ID = pol_users.partido_afiliado LIMIT 1) AS siglas
FROM pol_users " . $order_by . " LIMIT " . $p_limit, $link);
	while($row = mysql_fetch_array($result)){
		if ($row['nivel'] == 120) { $row['nivel'] = 1; }
		if ($row['online'] != 0) { $online = duracion($row['online']); } else { $online = ''; }
		if (substr($row['fecha_registro'], 0, 4) == '2004') { 
			$veterano = '(Veterano)';
		} elseif ($row['ref'] != 0) {
			$result2 = mysql_query("SELECT nick FROM pol_users WHERE ID = '" . $row['ref'] . "' LIMIT 1", $link);
			while($row2 = mysql_fetch_array($result2)){ $ref_nick = $row2['nick']; }
			$veterano = '(Ref: ' . crear_link($ref_nick) . ')';
		} else { 
			$veterano = ''; 
		}
		$txt .= '<tr><td align="right"><b>' . $row['nivel'] . '</b></td><td><b>' . crear_link($row['nick']) . '</b></td><td>' . crear_link($row['siglas'], 'partido') . '</td><td align="right">' . $online . '</td><td>' . explodear(' ', $row['fecha_registro'], 0) . '</td><td align="right">' . $row['num_elec'] . '</td><td align="right">' . $row['ref_num'] . '</td><td align="right">' . duracion(time() - strtotime($row['fecha_last'])) . '</td><td>' . $veterano . '</td></tr>' . "\n";
	}
	$txt .= '</table><p>' . $p_paginas . '</p>';
	$txt .= '<p>' . boton('Afiliarse', '/form/afiliarse/') . ' ' . boton('Estudiar', '/estudios/') . '</p>';
	
	$txt_title = 'Censo de Ciudadanos';
	break;
}



//THEME
include('theme.php');
?>