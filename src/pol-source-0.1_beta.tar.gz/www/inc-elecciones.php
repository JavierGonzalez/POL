<?php
/*
elecciones_estado  	elecciones
presidente 	Pablo1
num_esca�os 	3
elecciones_inicio 	2008-08-27 13:00:00
elecciones_duracion 	172800 2 dias
elecciones_frecuencia 	1036800 7+5 dias
elecciones_antiguedad 	86400 1 dia
*/


$elecciones_inicio_t = strtotime($pol['config']['elecciones_inicio']);
$elecciones_fin = $elecciones_inicio_t + $pol['config']['elecciones_duracion'];
if (($pol['config']['elecciones_estado'] == 'normal') AND (time() >= $elecciones_inicio_t)) { //INICIO

	mysql_query("DELETE FROM pol_elecciones", $link); //resetea votos
	mysql_query("UPDATE pol_config SET valor = 'elecciones' WHERE dato = 'elecciones_estado' LIMIT 1", $link);
	evento_chat('<b>[ELECCIONES]</b> <a href="/info/elecciones-generales/"><b>Comienzan las Elecciones Generales!</b></a>'); 


	$asunto = '[POL] Comienzan las Elecciones Generales de POL';
	$mensaje = 'Estimados ciudadanos y ciudadanas de POL,<br /><br />Acaban de comenzar las Elecciones Generales, en las que tienes el derecho y deber de participar. Su participacion es vital para que POL avance.<br /><br /><a href="http://pol.teoriza.com/"><b>http://pol.teoriza.com/</b></a><br /><br />POL, Tu Pueblo Virtual<br /><br /><br />Nota: Si no quieres recibir m�s emails puedes darte de baja como Ciudadano de POL o bien caducar� el usuario por inactividad en 15 dias.';

	$result = mysql_query("SELECT email FROM pol_users", $link);
	while($row = mysql_fetch_array($result)){
		enviar_email(null, $asunto, $mensaje, $row['email']);
	}


} elseif (($pol['config']['elecciones_estado'] == 'elecciones') AND (time() > $elecciones_fin)) { //FIN


	$elecciones_next = date('Y-m-d 22:00:00', time() + $pol['config']['elecciones_frecuencia']);
	mysql_query("UPDATE pol_config SET valor = '" . $elecciones_next . "' WHERE dato = 'elecciones_inicio' LIMIT 1", $link);
	mysql_query("UPDATE pol_config SET valor = 'normal' WHERE dato = 'elecciones_estado' LIMIT 1", $link);
	$result = mysql_query("SELECT user_ID FROM pol_diputados", $link);
	while($row = mysql_fetch_array($result)){ cargo_del(7, $row['user_ID']); }
	mysql_query("DELETE FROM pol_diputados", $link);

	$result = mysql_query("SELECT ID_partido, user_ID FROM pol_elecciones WHERE ID_partido != '0'", $link);
	while($row = mysql_fetch_array($result)){ $r[$row['ID_partido']]++; }

	$num_diputados = $pol['config']['num_esca�os'];
	for ($i=0;$i<$num_diputados;$i++) {
		$iteraccion++;
		arsort($r); reset($r);
		foreach($r as $ID_partido => $votos) {
		if (!$first) { //a�ade diputado
			$esca�os[$ID_partido]++; 
			$r[$ID_partido] = $votos / ($esca�os[$ID_partido] + 1);
			//a quien hacer Diputado
			if ($esca�os[$ID_partido] == 1) { //Presi del Partido
				$result = mysql_query("SELECT ID_presidente FROM pol_partidos WHERE ID = '" . $ID_partido . "' LIMIT 1", $link);
				while($row = mysql_fetch_array($result)){ $user_ID = $row['ID_presidente']; }
				if ($iteraccion == 1) { 
					//Hacer Presidente
					cargo_add(7, $user_ID);
					mysql_query("UPDATE pol_config SET valor = '" . $user_ID . "' WHERE dato = 'presidente'", $link); 
				} 
				//EL PRESIDENTE DE POL
			} else {
				$result = mysql_query("SELECT user_ID FROM pol_partidos_listas WHERE ID_partido = '" . $ID_partido . "' ORDER BY ID DESC LIMIT 1, " . $esca�os[$ID_partido], $link);
				while($row = mysql_fetch_array($result)){ $user_ID = $row['user_ID']; }
			}
			if ($iteraccion != 1) { cargo_add(6, $user_ID); }
			mysql_query("INSERT INTO pol_diputados (ID_partido, user_ID) VALUES ('" . $ID_partido . "', '" . $user_ID . "')", $link);
		} 
		$first++;
		}
		$first = null;
	}
	evento_chat('<b>[ELECCIONES]</b> <a href="/info/elecciones-generales/"><b>Han finalizado las Elecciones Generales!</b> Escrutinio publicado!</a>');
}
?>