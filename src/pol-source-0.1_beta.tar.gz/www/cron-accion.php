<?php 
if (!$link) {
	@include('inc-functions.php');
	@include('/home/teoriza/public_html/_blogs/conectar-mysql.php');
	$link = conectar('com');
}


$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_users", $link);
while($row = mysql_fetch_array($result)) {
	mysql_query("UPDATE pol_config SET valor = '" . $row['num'] . "' WHERE dato = 'info_censo' LIMIT 1", $link);
}

$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_docs WHERE estado = 'ok'", $link);
while($row = mysql_fetch_array($result)) {
	mysql_query("UPDATE pol_config SET valor = '" . $row['num'] . "' WHERE dato = 'info_documentos' LIMIT 1", $link);
}

$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_partidos WHERE estado = 'ok'", $link);
while($row = mysql_fetch_array($result)) {
	mysql_query("UPDATE pol_config SET valor = '" . $row['num'] . "' WHERE dato = 'info_partidos' LIMIT 1", $link);
}

$result = mysql_query("SELECT COUNT(ID) AS num FROM pol_ref WHERE estado = 'ok'", $link);
while($row = mysql_fetch_array($result)) {
	mysql_query("UPDATE pol_config SET valor = '" . $row['num'] . "' WHERE dato = 'info_consultas' LIMIT 1", $link);
}

?>