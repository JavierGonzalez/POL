<?php 
include('inc-login.php');

if ($_GET['a']) {

	$result = mysql_query("SELECT 
ID, siglas, nombre, descripcion, fecha_creacion, ID_presidente, 
(SELECT nick FROM pol_users WHERE ID = pol_partidos.ID_presidente LIMIT 1) AS nick_presidente
FROM pol_partidos 
WHERE siglas = '" . trim($_GET['a']) . "'
LIMIT 1", $link);
	while($row = mysql_fetch_array($result)){

		if (($_GET['b'] == 'editar') AND ($row['ID_presidente'] == $pol['user_ID'])) { //edit/

			//print listas
			$result2 = mysql_query("SELECT user_ID, orden, 
(SELECT nick FROM pol_users WHERE ID = pol_partidos_listas.user_ID LIMIT 1) AS nick
FROM pol_partidos_listas
WHERE ID_partido = '" . $row['ID'] . "'
ORDER BY ID ASC", $link);
			while($row2 = mysql_fetch_array($result2)){ 
				$li_listas .= '<li><form action="/accion.php?a=partido-lista&b=del&ID=' . $row['ID'] . '" method="post"><input type="hidden" name="user_ID" value="' . $row2['user_ID'] . '"  /><input style="height:26px;" type="submit" value="X" /> <b>' . crear_link($row2['nick']) . '</b></form></li>' . "\n"; 
			}


			$result2 = mysql_query("SELECT ID, nick, 
(SELECT user_ID FROM pol_partidos_listas WHERE ID_partido = '" . $row['ID'] . "' AND user_ID = pol_users.ID LIMIT 1) AS en_lista, 
(SELECT user_ID FROM pol_estudios_users WHERE ID_estudio = '6' AND user_ID = pol_users.ID AND estado = 'ok' LIMIT 1) AS es_diputado,
(SELECT siglas FROM pol_partidos WHERE ID_presidente = pol_users.ID LIMIT 1) AS es_presi
FROM pol_users 
WHERE estado = 'ciudadano' AND partido_afiliado = '" . $row['ID'] . "' AND ID != '" . $row['ID_presidente'] . "'
ORDER BY nick DESC", $link);
echo mysql_error($link);
			while($row2 = mysql_fetch_array($result2)){
				if ((!$row2['en_lista']) AND ($row2['es_diputado']) AND (!$row2['es_presi'])) {
					$ciudadanos .= '<option value="' . $row2['ID'] . '">' . $row2['nick'] . '</option>';
				}
			}

			$text = $row['descripcion'];

			$txt .= '<h1><img src="/img/doc-edit.gif" alt="Editar" /> ' . $row['siglas'] . ' (' . $row['nombre'] . ')</h1>
<ul id="partido">
<li>Introducci&oacute;n: (Descripci&oacute;n de la ideolog&iacute;a y propuestas)
<form action="/accion.php?a=partido-lista&b=edit&ID=' . $row['ID'] . '" method="post">
' . editor_enriquecido('text', $text) . '
<input type="submit" value="Guardar" /><br /></form></li>

<li><form action="/accion.php?a=partido-lista&b=add&ID=' . $row['ID'] . '" method="post"><select name="user_ID">' . $ciudadanos . '</select> <input type="submit" value="A&ntilde;adir a la lista" /> (deben ser afiliados a tu partido con el estudio de Diputado)</form></li>

<li>Lista:
<ol><li><b>' . crear_link($row['nick_presidente']) . ' (Presidente)</b></li>
' . $li_listas . '</ol></li>

<li><form action="/accion.php?a=partido-lista&b=ceder-presidencia&ID=' . $row['ID'] . '" method="post"><select name="user_ID">' . $ciudadanos . '</select> <input type="submit" value="Ceder Presidencia" onClick="if (!confirm(\'&iquest;Estas convencido de que quieres CEDER tu cargo de Presidente de ' . $row['siglas'] . ' para siempre?\')) { return false; }" /> (Ceder&aacute;s el control total del partido a este ciudadano)</form></li>
</ul>';



		} else {

			//count afiliados
			$result2 = mysql_query("SELECT COUNT(ID) FROM pol_users WHERE partido_afiliado = '" . $row['ID'] . "'", $link);
			while($row2 = mysql_fetch_array($result2)){ $num_afiliados = $row2['COUNT(ID)']; }

			//print listas
			$num_listas = 1;
			$result2 = mysql_query("SELECT user_ID, 
(SELECT nick FROM pol_users WHERE ID = pol_partidos_listas.user_ID LIMIT 1) AS nick
FROM pol_partidos_listas
WHERE ID_partido = '" . $row['ID'] . "'
ORDER BY ID ASC", $link);
			while($row2 = mysql_fetch_array($result2)){ 
				$li_listas .= '<li><b>' . crear_link($row2['nick']) . '</b></li>' . "\n";
				$num_listas++;
			}

			$txt_title = $row['siglas'] . ' - ' . $row['nombre'];

			$txt .= '<h1>' . $row['siglas'] . ' (' . $row['nombre'] . ')</h1>
<ul id="partido">
<li>Afiliados: <b>' . $num_afiliados . '</b></li>
<li>Lista: <b>' . $num_listas . '</b>
<ol><li><b>' . crear_link($row['nick_presidente']) . ' (Presidente)</b></li>' . $li_listas . '</ol></li>
</ul>
<p>' . $row['descripcion'] . '</p>';

		}
		$siglas_lower = strtolower($row['siglas']);
		$txt .= '<hr style="width:100%;" />';
		if (($row['ID_presidente'] == $pol['user_ID']) AND (!$_GET['b'])) { //PARA PRESIDENTE
			$txt .= '<span><form><input type="button" value="Editar" onClick="window.location.href=\'/partidos/' . $siglas_lower . '/editar/\';" /> <a href="/partidos/"><b>Ver todos los partidos</b></a></form></span>';
		} elseif ($_GET['b']) { $txt .= '<span style="float:right;"><form><input type="button" value="Eliminar" onClick="if (!confirm(\'&iquest;Estas convencido de que quieres ELIMINAR para siempre tu partido?\')) { return false; } else { window.location.href=\'/accion.php?a=eliminar-partido&siglas=' . $row['siglas'] . '\'; }"></form></span><span><a href="/partidos/' . $siglas_lower . '/"><b>Volver a tu partido</b></a></span>';
		} else { $txt .= '<span>' . boton('Afiliarse', '/form/afiliarse/' . $siglas_lower . '/') . ' <a href="/partidos/"><b>Ver todos los partidos</b></a></span>'; }


	} if (!$txt) { /*404*/ }


	$txt_header .= '<style type="text/css">#partido li { margin-top:5px; }</style>';
} else {

	$txt .= '<h1>Partidos Pol&iacute;ticos</h1>';

		$txt .= '<table border="0" class="pol_table">
<tr>
<th>Siglas</th>
<th>Nombre</th>
<th><acronym title="Afiliados/En Lista">Afiliados</acronym>&darr;</th>
<th>Presidente</th>
<th>Antig&uuml;edad</th>
<th><acronym title="Participaci&oacute;n en Elecciones">Elec</acronym></th>
</tr>';

	$result = mysql_query("SELECT 
ID, siglas, nombre, fecha_creacion, ID_presidente,
(SELECT nick FROM pol_users WHERE ID = pol_partidos.ID_presidente LIMIT 1) AS nick_presidente, 
(SELECT COUNT(ID) FROM pol_users WHERE partido_afiliado = pol_partidos.ID LIMIT 1) AS afiliados, 
(SELECT COUNT(ID) FROM pol_partidos_listas WHERE ID_partido = pol_partidos.ID LIMIT 1) AS num_lista
FROM pol_partidos 
WHERE estado = 'ok'
ORDER BY afiliados DESC, num_lista DESC", $link);
	while($row = mysql_fetch_array($result)){
		$num_lista = 1 + $row['num_lista'];
		if ($num_lista >= $pol['config']['num_esca�os']) { $num_lista = '<b>' . $num_lista . '</b>'; $elecciones = '<b style="color:blue;">ok</b>'; } else { $elecciones = '<b style="color:red;">no</b>'; }
		$txt .= '<tr><td><b style="font-size:20px;">' . crear_link($row['siglas'], 'partido') . '</b></td><td>' . $row['nombre'] . '</td><td><b>' . $row['afiliados'] . '</b>/' . $num_lista . '</td><td>' . crear_link($row['nick_presidente']) . '</td><td align="right">' . duracion(time() - strtotime($row['fecha_creacion'])) . '</td><td>' . $elecciones . '</td></tr>' . "\n";
	}
	$txt .= '</table>';

	$txt .= '<p>' . boton('Afiliarse', '/form/afiliarse/') . ' ' . boton('Crear Partido', '/form/crear-partido/') . ' &nbsp; <a href="/info/elecciones-generales/"><b>Ver Congreso</b></a></p>';
	$txt_title = 'Partidos Pol&iacute;ticos';
}




//THEME
include('theme.php');
?>