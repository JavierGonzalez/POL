<?php 
include('inc-login.php');

function polform($action, $pol_form, $submit='Enviar') {
	global $pol, $link;

	$f .= '<div class="pol_form">
<form action="/accion.php?a=' . $action . '" method="post">
<input type="hidden" name="user_ID" value="' . $pol['user_ID'] . '"  />
<ol>
';

	if ($pol_form) {
		foreach($pol_form as $v) {
			if (!$v['size']) { $v['size'] = '30'; }
			if (!$v['maxlenght']) { $v['maxlength'] = '255'; }

			switch ($v['type']) {
								
				case 'hidden':
					$f .= '<input type="hidden" name="' . $v['name'] . '" value="' . $v['value'] . '"  />' . "\n";
					
					break;

				case 'textrico':
					$f .= '<li><b>' . $v['nombre'] . ':</b><br />';
					$f .= editor_enriquecido($v['name']) . '</li>' . "\n";
					
					break;


				case 'text':
					$f .= '<li><b>' . $v['nombre'] . ':</b> ' . $v['desc'] . '<br /><input type="' . $v['type'] . '" name="' . $v['name'] . '" size="' . $v['size'] . '" maxlength="' . $v['maxlegth'] . '" /></li>' . "\n";
					break;

				case 'select_partidos':
					$f .= '<li><b>Partido Pol&iacute;tico:</b> Elige las siglas de tu partido o <em>ninguno</em>.<br /><select name="partido"><option value="0">Ninguno</option>';
					
					$result = mysql_query("SELECT siglas, ID FROM pol_partidos WHERE estado = 'ok' ORDER BY siglas ASC", $link);
					while($row = mysql_fetch_array($result)){
						if ($v['partido'] == strtolower($row['siglas'])) { $selected = ' selected="selected"'; } else { $selected = '';  }
						$f .= '<option value="' . $row['ID'] . '"' . $selected . '>' . $row['siglas'] . '</option>';
					}

					$f .= '</select></li>' . "\n";
					break;

				case 'select_nivel':
					$f .= '<li><b>Nivel de acceso:</b> Selecciona el nivel minimo necesario para editar el documento.<br />' . form_select_nivel() . '</li>' . "\n";
					break;

				case 'selectexpire':
					$f .= '<li><b>Duraci&oacute;n:</b> tiempo de expiraci&oacute;n de la expulsi&oacute;n.<br />
<select name="expire">
<option value="300">5 minutos</option>
<option value="900">15 minutos</option>
<option value="3600">1 hora</option>
<option value="18000">5 horas</option>
<option value="86400">1 d&iacute;a</option>
<option value="259200">3 d&iacute;as</option>
</select></li>' . "\n";
					break;

			}
		}
	}
	$f .= '<li><input type="submit" value="' . $submit . '" /></li></ol></form></div>';

	return $f;
}








switch ($_GET['a']) {


case 'expulsar':

	if ($_GET['b']) {
		//nick existe?
		mysql_query("DELETE FROM pol_ban WHERE expire < '" . date('Y-m-d H:i:s') . "'", $link);

		$result = mysql_query("SELECT ID, nick FROM pol_users WHERE nick = '" . $_GET['b'] . "' LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $nick = $row['nick']; $kick_user_ID = $row['ID']; }

		$result = mysql_unbuffered_query("SELECT ID FROM pol_estudios_users WHERE user_ID = '" . $pol['user_ID'] . "' AND cargo = '1'  AND (ID_estudio = '12' OR ID_estudio = '18' OR ID_estudio = '13') LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $es_poli = true; }

		if (($nick) AND ($es_poli)) {
			$txt .= '<h1>Expulsar a: ' . $nick . '</h1><p>Tienes acceso para ejecutar una expulsi&oacute;n de todas las salas de chat a este usuario, durante un tiempo determinado. Esta acci&oacute;n puede tener repercusiones si se emplea erroneamente.</p>';

			$pol_form = array(
			array('type'=>'hidden', 'name'=>'user_ID', 'value'=> $kick_user_ID),
			array('type'=>'selectexpire'),
			array('type'=>'text', 'name'=>'razon', 'value'=>'', 'size'=>'', 'size'=>'60', 'maxlegth'=>'255', 'nombre'=>'Raz&oacute;n', 'desc'=>'Frase con el motivo de esta expulsi&oacute;n. Se preciso.'),
			);
			$txt .= polform($_GET['a'], $pol_form, 'Expulsar');

		}
	} else {
		$txt .= '<h1>Expulsiones</h1>
<p>Tienes acceso para ejecutar una expulsi&oacute;n de todas las salas de chat a este usuario, durante un tiempo determinado. Esta acci&oacute;n puede tener repercusiones si se emplea erroneamente.</p>

<table border="0" cellspacing="1" cellpadding="" class="pol_table">
<tr>
<th>Expulsado &nbsp;</th>
<th>Por</th>
<th>Duraci&oacute;n</th>
<th>Raz&oacute;n</th>
<th></th>
</tr>';

	$result = mysql_query("SELECT razon, expire,
(SELECT nick FROM pol_users WHERE ID = pol_ban.user_ID LIMIT 1) AS expulsado,
(SELECT nick FROM pol_users WHERE ID = pol_ban.autor LIMIT 1) AS autor
FROM pol_ban
ORDER BY expire DESC", $link);
	while($row = mysql_fetch_array($result)){
		$txt .= '<tr><td><b>' . crear_link($row['expulsado']) . '</b></td><td>' . crear_link($row['autor']) . '</td><td>' . $row['expire'] . '</td><td>' . $row['razon'] . '</td><td></td></tr>' . "\n";
	}
	$txt .= '</table>';


	}

	break;


case 'elecciones-generales':


if ($pol['estado'] == 'ciudadano') { // ciudadano

		$txt .= '<h1>Elecciones Generales al Gobierno de POL</h1>';

	if ($pol['config']['elecciones_estado'] == 'normal') { 
		$txt .= '<p>Lo siento, a&uacute;n no puedes ejercer el derecho a voto.</p>';

	} elseif ($pol['config']['elecciones_estado'] == 'elecciones') {

		$fecha_24_antes = date('Y-m-d H:i:00', strtotime($pol['config']['elecciones_inicio']) - $pol['config']['elecciones_antiguedad']);

		//fecha registro?
		$result = mysql_query("SELECT fecha_registro FROM pol_users WHERE ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $fecha_registro = $row['fecha_registro']; }

		//ha votado?
		$result = mysql_query("SELECT ID FROM pol_elecciones WHERE user_ID = '" . $pol['user_ID'] . "' LIMIT 1", $link);
		while($row = mysql_fetch_array($result)){ $ha_votado = $row['ID']; }

		if ($fecha_registro >= $fecha_24_antes) {
			$txt .= '<p>No puedes ejercer el voto por falta de antiguedad, podr&aacute;s en las pr&oacute;ximas elecciones!</p>';
		} elseif ($ha_votado) { //ya ha votado
			$txt .= '<p><b>Voto correcto!</b> Felicidades.</p>';
		} else {
			$txt .= '
<ul>
<li>Debes ejercer tu derecho a voto, como buen Ciudadano de POL.</li>
<li>Solo podr&aacute;s votar una vez y de forma irrevocable, en estas Elecciones.</li>
<li>El voto ser&aacute; siempre an&oacute;nimo.</li>
<li>Puedes conocer los partidos <a href="/partidos/">aqu&iacute;</a>.</li>
<li>Informaci&oacute;n vital sobre las Elecciones Generales <a href="/doc/elecciones-generales/">aqu&iacute;</a>.</li>
</ul>';

			$result = mysql_query("SELECT ID, siglas, 
(SELECT COUNT(ID) FROM pol_partidos_listas WHERE ID_partido = pol_partidos.ID LIMIT 1) AS num_lista
FROM pol_partidos 
WHERE estado = 'ok' 
AND fecha_creacion < '" . $fecha_24_antes . "'
ORDER BY RAND()", $link);
			while($row = mysql_fetch_array($result)){
				if (($row['num_lista'] + 1) >= $pol['config']['num_esca�os']) {
					$partidos .= '<option value="' . $row['ID'] . '">' . $row['siglas'] . '</option>';
				}
			}
			$txt .= '<ol>
<li><form action="/accion.php?a=elecciones-generales" method="post"><select name="ID_partido" style="font-size:20px;color:green;">
<option value="0">En BLANCO</option>' . $partidos . '</select><br /><br /></li>
<li><input type="submit" value="VOTAR" /></form></li>
</ol>';
		}
	}
} else { $txt .= '<p>Solo los Ciudadanos de POL pueden ejercer su derecho a voto.</p>'; }


	break;



case 'crear-documento':

	$txt .= '<p>Formulario para crear un nuevo documento en POL.</p>';

	$pol_form = array(
	array('type'=>'select_nivel'),
	array('type'=>'text', 'name'=>'title', 'size'=>'60', 'maxlegth'=>'200', 'nombre'=>'T&iacute;tulo', 'desc'=>'Frase &uacute;nica a modo de titular del documento.'),
	array('type'=>'textrico', 'name'=>'text', 'size'=>'10', 'nombre'=>'Documento'),
	);
	$txt .= polform($_GET['a'], $pol_form, 'Crear documento');


	break;

case 'afiliarse':

	$txt .= '<p>Hola <b>' . $pol['nick'] . '</b>!</p> <p>Puedes afiliarte a cualquier partido o a ninguno, es una muestra tu fidelidad de forma simbolica.</p>';

	$pol_form = array(
	array('type'=>'select_partidos', 'partido'=>$_GET['b']),
	);
	$txt .= polform($_GET['a'], $pol_form, 'Afiliarse');


	break;

case 'crear-partido':

	$txt .= '<p>Formulario para crear un nuevo partido pol&iacute;tico en POL.</p>

<ul>
<li>Afirmas que el partido creado es legal en POL.</li>
</ul>
';
	$pol_form = array(
	array('type'=>'text', 'name'=>'siglas', 'value'=>'', 'size'=>'6', 'maxlegth'=>'6', 'nombre'=>'Siglas del partido', 'desc'=>'Escribe entre 2 y 6 letras may&uacute;sculas.'),
	array('type'=>'text', 'name'=>'nombre', 'value'=>'', 'size'=>'', 'maxlegth'=>'40', 'nombre'=>'Nombre del partido', 'desc'=>'Frase a modo de nombre que concuerda con las siglas anteriormente dadas.'),
	array('type'=>'textrico', 'name'=>'descripcion', 'size'=>'10', 'nombre'=>'Introducci&oacute;n'),
	);
	$txt .= polform($_GET['a'], $pol_form, 'Crear partido');


	break;

case 'solicitar-ciudadania':
	if (($pol['nick']) AND (!$pol['estado'])) {

		$txt .= '<p>Hola <b>' . $pol['nick'] . '</b>!</p> <p>A&uacute;n no eres un ciudadano de POL, eres un Turista. Con este formulario solicitar&aacute;s el proceso para ingresar como ciudadano.</p>

<ul>
<li>Est&aacute;s de acuerdo con los derechos y obligaciones como ciudadano de POL.</li>
<li>Tu nick cumple las leyes de POL.</li>
<li><b>Este es tu &uacute;nico usuario.</b></li>
</ul>
';

		$txt .= polform($_GET['a'], $pol_form, 'Acepto, solicito la ciudadan&iacute;a');
} else {
		$txt .= '<p>Debes tener un login de Teoriza registrado e identificado para solicitar tu ciudadan&iacute;a.</p>';
	}

	break;



default: header('Location: http://pol.teoriza.com/');
}






//THEME
$txt_title = 'Formulario';
include('theme.php');
?>